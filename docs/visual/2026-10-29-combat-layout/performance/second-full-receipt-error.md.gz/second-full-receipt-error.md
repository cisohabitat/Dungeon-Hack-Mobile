# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: combat-clarity.spec.js >> critical text fits beside filling warnings in Calm view and large numbers @mobile
- Location: test/browser/combat-clarity.spec.js:69:1

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 1
+ Received  + 0

  Array [
    "CRIT 18",
    "−6",
-   "MISS",
  ]
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - log [ref=e4]:
    - paragraph [ref=e5]: Cold stone halls stretch into darkness.
    - paragraph [ref=e6]: Welcome, Torvin the Fighter. 8 floors lie below. Find the Heart of the Mountain.
  - generic [ref=e7]:
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]:
          - generic [ref=e11]: Torvin
          - generic [ref=e12]: Fighter 1
        - generic [ref=e13]:
          - img "Life 20 of 20" [ref=e14]:
            - generic [ref=e16]: HP 20/20
          - img "Fed" [ref=e17]:
            - generic [ref=e19]: Fed
        - button "Quaff a healing draught (1 carried)" [ref=e20] [cursor=pointer]:
          - img [ref=e22]
          - generic [ref=e24]: Drink ×1
        - generic [ref=e25]:
          - generic [ref=e26]: Floor 1/8
          - generic [ref=e27]: 0 gold
          - generic [ref=e28]: "N"
      - generic [ref=e29]:
        - 'img "The dungeon. Facing north. Right in front of you: Orc, awake." [ref=e30]'
        - status
        - generic:
          - generic: Floor 1 of 8
          - generic: Grey Halls
        - generic "Open map" [ref=e31]
      - status [ref=e33]: Orc · Drawing back to strike
      - button "Message history" [ref=e34] [cursor=pointer]: ≡ Log
      - generic [ref=e35]:
        - generic [ref=e36]: Cold stone halls stretch into darkness.
        - generic [ref=e37]: Welcome, Torvin the Fighter. 8 floors lie below. Find the Heart of the Mountain.
    - generic [ref=e38]:
      - generic [ref=e39]:
        - generic [ref=e40]:
          - button "Turn left" [ref=e41] [cursor=pointer]:
            - img [ref=e43]
          - button "Forward" [ref=e46] [cursor=pointer]:
            - img [ref=e48]
          - button "Turn right" [ref=e50] [cursor=pointer]:
            - img [ref=e52]
          - button "Step left" [ref=e55] [cursor=pointer]:
            - img [ref=e57]
          - button "Back" [ref=e59] [cursor=pointer]:
            - img [ref=e61]
          - button "Step right" [ref=e63] [cursor=pointer]:
            - img [ref=e65]
        - generic [ref=e67]:
          - 'button "Attack: ready" [ref=e68] [cursor=pointer]':
            - img [ref=e70]
            - generic [ref=e79]: Attack
            - generic [ref=e80]: Ready
          - button "Use" [ref=e81] [cursor=pointer]:
            - img [ref=e83]
            - generic [ref=e88]: Use
          - 'button "Bash: break the blow in front of you and set it reeling" [ref=e89] [cursor=pointer]':
            - img [ref=e91]
            - generic [ref=e93]: Bash
      - generic [ref=e94]:
        - button "Map" [ref=e95] [cursor=pointer]
        - button "Pack" [ref=e96] [cursor=pointer]
        - button "Hero" [ref=e97] [cursor=pointer]
        - button "Journal" [ref=e98] [cursor=pointer]
        - 'button "Rest: not with foes near" [ref=e99] [cursor=pointer]':
          - text: Rest
          - generic [ref=e100]: foes near
        - button "Menu" [ref=e101] [cursor=pointer]
```

# Test source

```ts
  1   | 'use strict';
  2   | const { test, expect } = require('@playwright/test');
  3   | const AxeBuilder = require('@axe-core/playwright').default;
  4   | const { startGame, faceOpenGround, placeMonster, artReady, watchForErrors } = require('./helpers');
  5   | 
  6   | async function setup(page) {
  7   |   await page.addInitScript(() => { localStorage.setItem('deepdelve.sound', 'off'); localStorage.setItem('deepdelve.prelude', 'off'); });
  8   |   await startGame(page, { seed: 'combat-clarity' });
  9   |   await page.evaluate(() => { Game.level().monsters.length = 0; });
  10  |   expect(await faceOpenGround(page, 3)).toBeGreaterThanOrEqual(3);
  11  |   await placeMonster(page, 'orc', 1, { hp: 999, maxHp: 999 });
  12  |   await artReady(page);
  13  | }
  14  | 
  15  | test('visible enemy intent names attacks, shots, magic and charges without exposing hidden foes @mobile', async ({ page }) => {
  16  |   const errors = watchForErrors(page); await setup(page);
  17  |   const result = await page.evaluate(async () => {
  18  |     const { Dice, Odds } = await import('/js/rng.js');
  19  |     const { recordingPrint } = await import('/js/recording.js');
  20  |     const G = Game.state(), L = Game.level(), m = L.monsters[0], p = G.player;
  21  |     const draw = () => { const rs = Game.renderState(performance.now()); Renderer.render(rs.level, rs.cam, rs.sprites, rs.fx, performance.now()); return Renderer.intent; };
  22  |     const readings = [];
  23  |     for (const [id, kind, move] of [['orc', 'melee'], ['archer', 'shot'], ['acolyte', 'shot'], ['orc', 'move', 'charge']]) {
  24  |       m.id = id; m.windup = { kind, move, at: G.t - 800, until: G.t + 1e6 };
  25  |       readings.push(draw());
  26  |     }
  27  |     m.id = 'archer'; m.windup = null; m.volley = { left: 2, next: G.t + 1e6 };
  28  |     const volley = draw(), volleyGlyph = Game.renderState(performance.now()).sprites.find(s => s.maxHp === 999).tellKind;
  29  |     m.id = 'orc'; m.volley = null; m.windup = { kind: 'move', move: 'charge', at: G.t - 800, until: G.t + 1e6 };
  30  |     m.pack = [{ hp: 20, maxHp: 20 }];
  31  |     // Render calls are themselves recorded and reveal visible map columns.
  32  |     // Compare the existing outcome print, plus both exact dice states.
  33  |     draw();
  34  |     const before = recordingPrint(G), dice = [Dice.s, Odds.s];
  35  |     const pack = draw(), unchanged = before === recordingPrint(G) && dice[0] === Dice.s && dice[1] === Odds.s;
  36  |     const idx = m.y * L.w + m.x, tile = L.tiles[idx]; L.tiles[idx] = Dungeon.T.WALL;
  37  |     const occluded = draw(); L.tiles[idx] = tile;
  38  |     m.x = p.x - Dungeon.DIRS[p.dir][0]; m.y = p.y - Dungeon.DIRS[p.dir][1]; m.rx = m.x; m.ry = m.y;
  39  |     const behind = draw();
  40  |     m.x = p.x + Dungeon.DIRS[p.dir][0]; m.y = p.y + Dungeon.DIRS[p.dir][1]; m.rx = m.x; m.ry = m.y;
  41  |     m.windup = { kind: 'pet', at: G.t - 500, until: G.t + 1e6 }; const companion = draw();
  42  |     return { readings, volley, volleyGlyph, pack, unchanged, occluded, behind, companion };
  43  |   });
  44  |   expect(result.readings).toEqual(['Orc · Drawing back to strike', 'Goblin Archer · Aiming a shot', 'Dark Acolyte · Casting', 'Orc · Charging']);
  45  |   expect(result.volley).toBe('Goblin Archer · Firing a volley'); expect(result.volleyGlyph).toBe('shot');
  46  |   expect(result.pack).toBe('Orc · Charging'); expect(result.unchanged).toBe(true);
  47  |   expect(result.occluded).toBe(''); expect(result.behind).toBe(''); expect(result.companion).toBe('Orc · Attacking companion');
  48  |   await expect(page.locator('#combat-intent')).toContainText('Attacking companion');
  49  |   await page.evaluate(() => { Game.level().monsters[0].windup = null; });
  50  |   await expect(page.locator('#combat-intent')).toBeHidden(); expect(errors).toEqual([]);
  51  | });
  52  | 
  53  | test('landed damage and critical hits keep their actual outcome and readable labels @mobile', async ({ page }) => {
  54  |   const errors = watchForErrors(page); await setup(page);
  55  |   const result = await page.evaluate(() => {
  56  |     const p = Game.player(), m = Game.level().monsters[0];
  57  |     p.eq.weapon = { t: 'longsword', q: 1, e: 0 };
  58  |     let critical = false, damage = false, miss = false;
  59  |     for (let i = 0; i < 200 && !(critical && damage && miss); i++) {
  60  |       p.nextAttack = 0; Game.input('attack');
  61  |       const texts = Game.renderState(performance.now() + 100).fx.texts;
  62  |       critical ||= texts.some(t => t.outcome === 'critical'); damage ||= texts.some(t => t.outcome === 'damage'); miss ||= texts.some(t => t.text === 'miss');
  63  |     }
  64  |     return { critical, damage, miss, hurt: m.hp < 999 };
  65  |   });
  66  |   expect(result).toEqual({ critical: true, damage: true, miss: true, hurt: true }); expect(errors).toEqual([]);
  67  | });
  68  | 
  69  | test('critical text fits beside filling warnings in Calm view and large numbers @mobile', async ({ page }, info) => {
  70  |   const errors = watchForErrors(page); await setup(page);
  71  |   const result = await page.evaluate(() => {
  72  |     const m = Game.level().monsters[0], at = performance.now(), G = Game.state();
  73  |     m.windup = { kind: 'melee', at: G.t - 800, until: G.t + 200 };
  74  |     const rs = Game.renderState(at); rs.fx.texts = [
  75  |       { x: m.rx + .5, y: m.ry + .5, text: '18', outcome: 'critical', color: '#ffff44', born: at - 80, until: at + 670, lift: 0 },
  76  |       { x: m.rx + .5, y: m.ry + .5, text: '6', outcome: 'damage', color: '#ffffff', born: at - 80, until: at + 670, lift: 1 },
  77  |       { x: m.rx + .5, y: m.ry + .5, text: 'miss', color: '#e4e4ee', born: at - 80, until: at + 670, lift: 2 }
  78  |     ];
  79  |     Renderer.setCalm(true); Renderer.setBigNumbers(true);
  80  |     const render = Renderer.render; Renderer.render = () => render(rs.level, rs.cam, rs.sprites, rs.fx, at);
  81  |     Renderer.render();
  82  |     const numbers = Renderer.numbers, warnings = Renderer.shown.filter(s => s.markSize);
  83  |     const edges = [-.65, .65].map(side => {
  84  |       rs.fx.texts = [{ ...rs.fx.texts[0], x: m.rx + .5 - Dungeon.DIRS[Game.player().dir][1] * side, y: m.ry + .5 + Dungeon.DIRS[Game.player().dir][0] * side }];
  85  |       Renderer.render(); return Renderer.numbers;
  86  |     });
  87  |     rs.fx.texts = [{ x:m.rx+.5, y:m.ry+.5, text:'18', outcome:'critical', color:'#ffff44', born:at-80, until:at+670, lift:0 }];
  88  |     return { numbers, warnings, edges, width: Renderer.W };
  89  |   });
> 90  |   expect(result.numbers.map(n => n.label)).toEqual(['CRIT 18', '−6', 'MISS']);
      |                                            ^ Error: expect(received).toEqual(expected) // deep equality
  91  |   for (const n of result.numbers) {
  92  |     expect(n.x - n.half).toBeGreaterThanOrEqual(0); expect(n.x + n.half).toBeLessThanOrEqual(result.width);
  93  |     for (const w of result.warnings) if (n.y > w.markY - w.markSize && n.y - 23 < w.markY + 2) expect(Math.abs(n.x - w.markX)).toBeGreaterThan(w.markSize * .62 + n.half);
  94  |   }
  95  |   for (const edge of result.edges) { expect(edge).toHaveLength(1); expect(edge[0].x - edge[0].half).toBeGreaterThanOrEqual(0); expect(edge[0].x + edge[0].half).toBeLessThanOrEqual(result.width); }
  96  |   await page.screenshot({ path: info.outputPath('critical-warning.png') }); expect(errors).toEqual([]);
  97  | });
  98  | 
  99  | test('condition countdowns retain focus, explain themselves and expire with the delve clock @mobile', async ({ page }) => {
  100 |   const errors = watchForErrors(page); await setup(page);
  101 |   await page.evaluate(() => {
  102 |     Game.level().monsters = []; const G = Game.state(), p = G.player;
  103 |     p.held = G.t + 14000; p.heldBy = 'down'; p.webbed = G.t + 12000; p.dazzled = G.t + 11000;
  104 |     p.hexed = { kind: 'silence', until: G.t + 15000 }; p.riposteUntil = G.t + 10000;
  105 |   });
  106 |   for (const name of ['Knocked down', 'Webbed', 'Dazzled', 'Silenced', 'Riposte ready']) await expect(page.locator('#hud-status button', { hasText: name })).toHaveText(new RegExp(`${name} \\d+s`));
  107 |   const chip = page.locator('#hud-status button', { hasText: 'Webbed' }); await chip.focus();
  108 |   const before = await chip.textContent(); await expect(chip).not.toHaveText(before); await expect(chip).toBeFocused();
  109 |   await chip.click(); await expect(page.locator('#journal-list')).toContainText('Trying to move tears at the web');
  110 |   await page.keyboard.press('Escape');
  111 |   await page.evaluate(() => { const G = Game.state(), p = G.player; p.webbed = p.held = p.dazzled = p.riposteUntil = G.t - 1; p.hexed = null; });
  112 |   await expect(page.locator('#hud-status button.bad')).toHaveCount(0); expect(errors).toEqual([]);
  113 | });
  114 | 
  115 | test('death advice explains the recorded source, includes conditions and escapes hostile text @mobile', async ({ page }, info) => {
  116 |   const errors = watchForErrors(page); await setup(page);
  117 |   await page.evaluate(() => {
  118 |     Game.level().monsters = []; const G = Game.state(), p = G.player;
  119 |     p.poison = { until: G.t + 20000, next: G.t + 1e6 }; p.hp = 1;
  120 |     Game.hurtPlayer(3, 'The poison burns in your veins.', null, 'poison');
  121 |   });
  122 |   await expect(page.locator('#screen-end')).toBeVisible();
  123 |   await expect(page.locator('#end-cause')).toContainText('poison');
  124 |   await expect(page.locator('#end-lesson')).toContainText('does not remove poison');
  125 |   await page.locator('#end-lesson summary').click(); await expect(page.locator('#end-lesson')).toContainText('Poisoned');
  126 |   const pure = await page.evaluate(async () => {
  127 |     const { deathLesson } = await import('/js/delveguide.js'), { Dice, Odds } = await import('/js/rng.js');
  128 |     const G = Game.state(); G.lastAttacker.name = '<img src=x onerror=alert(1)>'; const before = JSON.stringify(G), dice = [Dice.s, Odds.s];
  129 |     const html = deathLesson(); return !html.includes('<img') && before === JSON.stringify(G) && dice[0] === Dice.s && dice[1] === Odds.s;
  130 |   });
  131 |   expect(pure).toBe(true); await page.screenshot({ path: info.outputPath('death-lesson.png') }); expect(errors).toEqual([]);
  132 | });
  133 | 
  134 | test('crowded combat keeps conditions bounded, touch targets reachable and the view accessible @mobile', async ({ page }, info) => {
  135 |   const errors = watchForErrors(page); await setup(page);
  136 |   await page.evaluate(() => {
  137 |     const G = Game.state(), p = G.player, m = Game.level().monsters[0];
  138 |     p.poison = { until: G.t + 1e6, next: G.t + 1e6 }; p.webbed = p.dazzled = p.riposteUntil = G.t + 1e6;
  139 |     p.hexed = { kind: 'slow', until: G.t + 1e6 };
  140 |     for (const key of ['ac', 'hit', 'might', 'boon_ac', 'crew_hit']) p.effects[key] = { amount: 2, until: G.t + 1e6 };
  141 |     m.windup = { kind: 'move', move: 'charge', at: G.t - 500, until: G.t + 1e6 };
  142 |   });
  143 |   await expect(page.locator('#combat-intent')).toContainText('Charging');
  144 |   for (const [width, height, large] of [[320,568,false],[390,844,false],[844,390,false],[320,568,true],[844,390,true]]) {
  145 |     await page.setViewportSize({ width, height });
  146 |     await page.evaluate(large => { document.body.classList.toggle('big-text', large); document.documentElement.style.fontSize = large ? '32px' : ''; }, large);
  147 |     await expect.poll(() => page.evaluate(() => document.querySelector('#hud-status').clientHeight)).toBeLessThanOrEqual(height < width ? 44 : 96);
  148 |     const geometry = await page.evaluate(() => {
  149 |       const chips = document.querySelector('#hud-status');
  150 |       return { overflow: document.documentElement.scrollWidth > innerWidth, scroll: chips.scrollHeight > chips.clientHeight || chips.scrollWidth > chips.clientWidth,
  151 |         targets: [...chips.querySelectorAll('button')].every(b => b.getBoundingClientRect().width >= 44 && b.getBoundingClientRect().height >= 44), view: document.querySelector('#view').getBoundingClientRect().height };
  152 |     });
  153 |     expect(geometry.overflow).toBe(false); expect(geometry.targets).toBe(true); expect(geometry.scroll).toBe(true); expect(geometry.view).toBeGreaterThan(40);
  154 |     await page.screenshot({ path: info.outputPath(`crowded-${width}-${large}.png`) });
  155 |   }
  156 |   await page.setViewportSize({ width:390, height:844 });
  157 |   await page.evaluate(() => { document.body.classList.remove('big-text'); document.documentElement.style.fontSize = ''; });
  158 |   const audit = await new AxeBuilder({ page }).include('#screen-game').analyze();
  159 |   expect(audit.violations.filter(v => ['serious','critical'].includes(v.impact))).toEqual([]); expect(errors).toEqual([]);
  160 | });
  161 | 
  162 | test('aligned crowd damage receipts stay apart at different depths @mobile', async ({page}) => {
  163 |   await setup(page);
  164 |   for (const big of [false,true]) {
  165 |     const boxes=await page.evaluate(big=>{
  166 |       const m=Game.level().monsters[0],at=performance.now(),rs=Game.renderState(at),D=Dungeon.DIRS[Game.player().dir];
  167 |       rs.fx.texts=[0,1,2].map((depth,i)=>({x:m.rx+.5+D[0]*depth,y:m.ry+.5+D[1]*depth,text:String(18+i),outcome:'damage',color:'#fff',born:at-80,until:at+670,lift:0}));
  168 |       Renderer.setBigNumbers(big);Renderer.render(rs.level,rs.cam,rs.sprites,rs.fx,at);return Renderer.numbers;
  169 |     },big);
  170 |     expect(boxes).toHaveLength(3);
  171 |     for(let i=0;i<boxes.length;i++)for(let j=0;j<i;j++)expect(Math.abs(boxes[i].y-boxes[j].y)).toBeGreaterThanOrEqual(big?26:19);
  172 |   }
  173 | });
  174 | 
```