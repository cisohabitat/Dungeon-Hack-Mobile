# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: interface.spec.js >> interface >> sideways the view is big, the log shows three lines, a tip is small print, and nothing sits over the fight or the hands
- Location: test/browser/interface.spec.js:402:3

# Error details

```
Error: and taller (265)

expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 300
Received:    291.640625
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - log [ref=e4]:
    - paragraph [ref=e5]: Cold stone halls stretch into darkness.
    - paragraph [ref=e6]: Welcome, Aldous the Mage. 8 floors lie below. Find the Heart of the Mountain.
    - paragraph [ref=e7]: Line 2 of the log.
    - paragraph [ref=e8]: Line 3 of the log.
    - paragraph [ref=e9]: Line 4 of the log.
    - paragraph [ref=e10]: Line 5 of the log.
    - paragraph [ref=e11]: Line 6 of the log.
  - generic [ref=e12]:
    - generic [ref=e13]:
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Aldous
          - generic [ref=e17]: Mage 1
        - generic [ref=e18]:
          - img "Life 19 of 19" [ref=e19]:
            - generic [ref=e21]: HP 19/19
          - img "Spell points 12 of 12" [ref=e22]:
            - generic [ref=e24]: SP 12/12
          - img "Fed" [ref=e25]:
            - generic [ref=e27]: Fed
        - button "Quaff a healing draught (2 carried)" [ref=e28] [cursor=pointer]:
          - img [ref=e30]
          - generic [ref=e32]: Drink ×2
        - generic [ref=e33]:
          - generic [ref=e34]: Floor 1/8
          - generic [ref=e35]: 0 gold
          - generic [ref=e36]: E
      - generic [ref=e37]:
        - 'img "The dungeon. Facing east. Two squares ahead: Goblin, awake." [ref=e38]'
        - status: "A violet spiked mark means a trick armour will not turn: get out of the way. The log says what is coming, and the Bestiary (Journal) records each trick."
        - generic:
          - generic: Floor 1 of 8
          - generic: Grey Halls
        - generic "Open map" [ref=e39]
      - generic:
        - 'button "Take what lies here: Potion of Healing, Iron Ration" [ref=e41] [cursor=pointer]':
          - generic [ref=e43]: Take
        - button "Read the Scroll of Fire" [ref=e44] [cursor=pointer]:
          - generic [ref=e45]: Fire
        - button "Message history" [ref=e46] [cursor=pointer]: ≡ Log
      - generic [ref=e47]:
        - generic [ref=e48]: Line 4 of the log.
        - generic [ref=e49]: Line 5 of the log.
        - generic [ref=e50]: Line 6 of the log.
    - generic [ref=e51]:
      - generic [ref=e52]:
        - generic [ref=e53]:
          - button "Turn left" [ref=e54] [cursor=pointer]:
            - img [ref=e56]
          - button "Forward" [ref=e59] [cursor=pointer]:
            - img [ref=e61]
          - button "Turn right" [ref=e63] [cursor=pointer]:
            - img [ref=e65]
          - button "Step left" [ref=e68] [cursor=pointer]:
            - img [ref=e70]
          - button "Back" [ref=e72] [cursor=pointer]:
            - img [ref=e74]
          - button "Step right" [ref=e76] [cursor=pointer]:
            - img [ref=e78]
        - generic [ref=e80]:
          - 'button "Attack: ready" [ref=e81] [cursor=pointer]':
            - img [ref=e83]
            - generic [ref=e92]: Attack
            - generic [ref=e93]: Ready
          - button "Take" [ref=e94] [cursor=pointer]:
            - img [ref=e96]
            - generic [ref=e101]: Take
          - button "Cast Magic Missile" [ref=e102] [cursor=pointer]:
            - img [ref=e104]
            - generic [ref=e107]: Magic Missile
      - generic [ref=e108]:
        - button "Map" [ref=e109] [cursor=pointer]
        - button "Pack" [ref=e110] [cursor=pointer]
        - button "Spells" [ref=e111] [cursor=pointer]
        - button "Hero" [ref=e112] [cursor=pointer]
        - button "Journal" [ref=e113] [cursor=pointer]
        - 'button "Rest: not with foes near" [ref=e114] [cursor=pointer]':
          - text: Rest
          - generic [ref=e115]: foes near
        - button "Menu" [ref=e116] [cursor=pointer]
```

# Test source

```ts
  331 |       .toContain('the message after the cap');
  332 |     expect(after, 'the panel should have moved on').not.toBe(full);
  333 | 
  334 |     // and the capped array itself is still doing its job
  335 |     const size = await page.evaluate(() => Game.state().log.length);
  336 |     expect(size, 'the log should stay capped').toBeLessThanOrEqual(80);
  337 |     // one message taller than the panel shows from its start, not its middle
  338 |     await page.evaluate(() => Game.log('BEGINNING of a very long message. ' + 'It goes on and on, far longer than the panel is tall, as a shade\'s arrival does. '.repeat(6) + 'END'));
  339 |     await expect.poll(() => page.evaluate(() => {
  340 |       const el = document.querySelector('#log'), first = el.firstElementChild;
  341 |       return first && first.textContent.startsWith('BEGINNING') && first.getBoundingClientRect().top >= el.getBoundingClientRect().top;
  342 |     })).toBe(true);
  343 |     expect(errors).toEqual([]);
  344 |   });
  345 | 
  346 |   for (const [label, vp] of Object.entries({
  347 |     'small phone': { width: 360, height: 640 },
  348 |     'iPhone SE': { width: 375, height: 667 },
  349 |     'tall phone': { width: 393, height: 851 },
  350 |     'landscape phone': { width: 844, height: 390 },
  351 |     'small landscape': { width: 740, height: 360 },
  352 |     desktop: { width: 1280, height: 800 },
  353 |   })) {
  354 |     test(`every control can be reached on a ${label}`, async ({ page }) => {
  355 |       // A landscape phone once had Cast below the bottom edge: a spellcaster
  356 |       // playing sideways could not cast at all, and nothing noticed.
  357 |       const errors = watchForErrors(page);
  358 |       await page.setViewportSize(vp);
  359 |       await startGame(page, { seed: 'reach' });
  360 |       await clearBoons(page);
  361 |       await page.waitForTimeout(250);
  362 |       const out = await page.evaluate(() => [...document.querySelectorAll('#screen-game .ctl, #screen-game .bottombar button')]
  363 |         // a button this hero has no use for (Spells, for a fighter) is not shown at all
  364 |         .filter(b => getComputedStyle(b).display !== 'none')
  365 |         .filter(b => { const r = b.getBoundingClientRect(); return r.bottom > innerHeight + 1 || r.right > innerWidth + 1 || r.top < -1 || r.height < 30; })
  366 |         .map(b => b.getAttribute('aria-label') || b.textContent.trim()));
  367 |       expect(out, 'controls off screen or too small to press').toEqual([]);
  368 |       expect(errors).toEqual([]);
  369 |     });
  370 |   }
  371 | 
  372 |   test('a phone held sideways puts the view beside the controls, filled and with nothing off the edge', async ({ page }) => {
  373 |     // Sideways the view was a short 16:10 picture with black bars down both
  374 |     // sides, and the seven buttons of the bottom bar were each under 44px wide.
  375 |     const errors = watchForErrors(page);
  376 |     await page.setViewportSize({ width: 851, height: 393 });
  377 |     await startGame(page, { seed: 'sideways', cls: 'Mage' });
  378 |     await clearBoons(page);
  379 |     await page.waitForTimeout(250);
  380 |     const v = await page.evaluate(() => {
  381 |       const c = document.getElementById('view'), box = c.parentElement.getBoundingClientRect();
  382 |       const buttons = [...document.querySelectorAll('#screen-game .ctl, #screen-game .bottombar button')]
  383 |         .filter(b => getComputedStyle(b).display !== 'none')
  384 |         .map(b => { const r = b.getBoundingClientRect(); return { name: b.getAttribute('aria-label') || b.textContent.trim(), left: r.left, top: r.top, right: r.right, bottom: r.bottom, w: r.width, h: r.height }; });
  385 |       return { box: { left: box.left, right: box.right, width: box.width, height: box.height }, buffer: [c.width, c.height], buttons,
  386 |         // how much of the box the picture fills once it is fitted inside it
  387 |         fill: Math.min(1, (box.height * c.width / c.height) / box.width),
  388 |         overflow: document.documentElement.scrollWidth - document.documentElement.clientWidth };
  389 |     });
  390 |     expect(v.overflow, 'no sideways scroll').toBeLessThanOrEqual(0);
  391 |     expect(v.box.width / 851, 'the view should take most of the width').toBeGreaterThan(0.55);
  392 |     expect(v.fill, 'the picture should fill its box, not sit between black bars').toBeGreaterThan(0.97);
  393 |     expect(v.buffer[1], 'the renderer should draw a wider picture, not scale a narrow one').toBeLessThan(200);
  394 |     expect(v.buttons.length).toBeGreaterThanOrEqual(15);
  395 |     const beside = v.buttons.filter(b => b.left < v.box.right - 1);
  396 |     expect(beside.map(b => b.name), 'every control should sit to the right of the view').toEqual([]);
  397 |     const bad = v.buttons.filter(b => b.top < -1 || b.bottom > 393 + 1 || b.right > 851 + 1 || b.w < 44 || b.h < 44);
  398 |     expect(bad.map(b => `${b.name} ${Math.round(b.w)}x${Math.round(b.h)}`), 'controls off screen or too small to press').toEqual([]);
  399 |     expect(errors).toEqual([]);
  400 |   });
  401 | 
  402 |   test('sideways the view is big, the log shows three lines, a tip is small print, and nothing sits over the fight or the hands', async ({ page }) => {
  403 |     // A playtest on an 851 by 393 phone: the view was 525 by 265, a first tip
  404 |     // covered a quarter of it, the log showed two lines, what lay underfoot
  405 |     // covered the monster in front and the quick scroll covered the shield.
  406 |     const errors = watchForErrors(page);
  407 |     await page.setViewportSize({ width: 851, height: 393 });
  408 |     await startGame(page, { seed: 'sideways-2', cls: 'Mage' });
  409 |     await clearBoons(page);
  410 |     await page.evaluate(() => {
  411 |       const p = Game.player(), L = Game.level(), G = Game.state(), [dx, dy] = Dungeon.DIRS[p.dir];
  412 |       L.monsters.length = 0;
  413 |       for (let i = 1; i <= 2; i++) L.tiles[(p.y + dy * i) * L.w + p.x + dx * i] = Dungeon.T.FLOOR;
  414 |       L.monsters.push({ uid: 94, id: 'goblin', x: p.x + dx * 2, y: p.y + dy * 2, hp: 500, maxHp: 500, awake: true, spoke: true, nextAct: G.t + 1e9, rx: p.x + dx * 2, ry: p.y + dy * 2, fromX: 0, fromY: 0, moveT0: 0, moveT1: 0, flashUntil: 0 });
  415 |       p.inv.push({ t: 'scroll_fire', q: 1, e: 0 }); G.known.scroll_fire = 1;
  416 |       L.items[p.x + ',' + p.y] = [{ t: 'potion_heal', q: 1, e: 0 }, { t: 'ration', q: 1, e: 0 }];
  417 |       for (let i = 1; i <= 6; i++) Game.log(`Line ${i} of the log.`);
  418 |     });
  419 |     await expect(page.locator('#quick-scroll')).toBeVisible({ timeout: 2000 });
  420 |     await expect(page.locator('#feet')).toBeVisible({ timeout: 2000 });
  421 |     const v = await page.evaluate(() => {
  422 |       const box = el => { const r = (typeof el === 'string' ? document.querySelector(el) : el).getBoundingClientRect(); return { left: r.left, top: r.top, right: r.right, bottom: r.bottom, w: r.width, h: r.height }; };
  423 |       const tip = document.getElementById('tip');
  424 |       tip.innerHTML = UI.tips().trick; tip.classList.add('show');
  425 |       const log = box('#log');
  426 |       return { view: box('#view'), log, tip: box(tip), feet: box('#feet'), scroll: box('#quick-scroll'), more: box('#log-more'),
  427 |         lines: [...document.querySelectorAll('#log div')].filter(d => { const r = d.getBoundingClientRect(); return r.top >= log.top - 0.5 && r.bottom <= log.bottom + 0.5; }).length };
  428 |     });
  429 |     const overlaps = (a, b) => a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1;
  430 |     expect(v.view.w, 'the view is wider than it was (525)').toBeGreaterThanOrEqual(600);
> 431 |     expect(v.view.h, 'and taller (265)').toBeGreaterThanOrEqual(300);
      |                                          ^ Error: and taller (265)
  432 |     expect(v.lines, 'three lines of the log or more').toBeGreaterThanOrEqual(3);
  433 |     expect(v.tip.h / v.view.h, 'even the longest tip takes little of the view').toBeLessThan(0.16);
  434 |     expect(overlaps(v.feet, v.view), 'what lies underfoot sits outside the view').toBe(false);
  435 |     expect(overlaps(v.scroll, v.view), 'the quick scroll sits outside the view').toBe(false);
  436 |     expect(overlaps(v.feet, v.more) || overlaps(v.scroll, v.more) || overlaps(v.feet, v.scroll), 'nothing on top of the Log button, or of each other').toBe(false);
  437 |     for (const b of [v.feet, v.scroll]) {
  438 |       expect(b.w >= 44 && b.h >= 44, 'big enough for a thumb').toBe(true);
  439 |       expect(b.bottom, 'inside the screen').toBeLessThanOrEqual(393);
  440 |     }
  441 |     expect(errors).toEqual([]);
  442 |   });
  443 | 
  444 |   test('upright, the quick scroll is out of the view, off the shield or focus held low in its corner', async ({ page }) => {
  445 |     for (const vp of [{ width: 393, height: 851 }, { width: 393, height: 727 }, { width: 360, height: 640 }]) {
  446 |       await page.setViewportSize(vp);
  447 |       if (vp.height === 851) {
  448 |         await startGame(page, { seed: 'upright-scroll', cls: 'Cleric' });
  449 |         await clearBoons(page);
  450 |         await page.evaluate(() => {
  451 |           const p = Game.player(), L = Game.level(), G = Game.state(), [dx, dy] = Dungeon.DIRS[p.dir];
  452 |           L.monsters.length = 0;
  453 |           for (let i = 1; i <= 2; i++) L.tiles[(p.y + dy * i) * L.w + p.x + dx * i] = Dungeon.T.FLOOR;
  454 |           L.monsters.push({ uid: 95, id: 'goblin', x: p.x + dx * 2, y: p.y + dy * 2, hp: 500, maxHp: 500, awake: true, spoke: true, nextAct: G.t + 1e9, rx: p.x + dx * 2, ry: p.y + dy * 2, fromX: 0, fromY: 0, moveT0: 0, moveT1: 0, flashUntil: 0 });
  455 |           p.inv.push({ t: 'scroll_fire', q: 1, e: 0 }); G.known.scroll_fire = 1;
  456 |         });
  457 |         await expect(page.locator('#quick-scroll')).toBeVisible({ timeout: 2000 });
  458 |       }
  459 |       await page.waitForTimeout(200);
  460 |       const r = await page.evaluate(() => {
  461 |         const s = document.getElementById('quick-scroll').getBoundingClientRect(), v = document.getElementById('view').getBoundingClientRect(), l = document.getElementById('log').getBoundingClientRect();
  462 |         return { below: s.top >= v.bottom - 1, inLog: s.bottom <= l.bottom + 1, left: s.left < v.left + v.width / 3 };
  463 |       });
  464 |       expect(r, `at ${vp.width}x${vp.height}`).toEqual({ below: true, inLog: true, left: true });
  465 |     }
  466 |   });
  467 | 
  468 |   test('on a tall phone the view grows into the spare height without stretching', async ({ page }) => {
  469 |     const errors = watchForErrors(page);
  470 |     await page.setViewportSize({ width: 393, height: 851 });
  471 |     await startGame(page, { seed: 'tall-view' });
  472 |     await clearBoons(page);
  473 |     await page.waitForTimeout(250);
  474 |     const v = await page.evaluate(() => {
  475 |       const c = document.getElementById('view'), b = c.getBoundingClientRect();
  476 |       const pad = document.querySelector('.dpad').getBoundingClientRect(), ctl = document.querySelector('.controls').getBoundingClientRect();
  477 |       return { share: b.height / innerHeight, buffer: c.height, aspect: (b.width / c.width) / (b.height / c.height),
  478 |         slack: ctl.height - pad.height };
  479 |     });
  480 |     // the view used to be fixed at 16:10, under 30% of the screen, while the
  481 |     // controls padded a quarter of it with nothing
  482 |     expect(v.share, 'the view should take a real share of a tall screen').toBeGreaterThan(0.4);
  483 |     expect(v.buffer, 'the renderer should draw a taller picture, not scale a short one').toBeGreaterThan(260);
  484 |     expect(Math.abs(v.aspect - 1), 'pixels should stay square').toBeLessThan(0.03);
  485 |     expect(v.slack, 'the controls should not be padded with empty space').toBeLessThan(40);
  486 |     expect(errors).toEqual([]);
  487 |   });
  488 | 
  489 |   test('on a narrow phone the message box wraps rather than cutting off the roll', async ({ page }) => {
  490 |     const errors = watchForErrors(page);
  491 |     await page.setViewportSize({ width: 360, height: 780 });
  492 |     await startGame(page, { seed: 'log-wrap' });
  493 |     await clearBoons(page);
  494 |     // the longest lines the game writes, each ending in the part worth reading;
  495 |     // with the floor emptied first, so nothing that wakes can write after them
  496 |     await page.evaluate(() => {
  497 |       Game.level().monsters.length = 0;
  498 |       Game.log('You hit the Goblin for 7. (d20 14+5 vs AC 13)');
  499 |       Game.log('The Goblin Archer shoots an arrow at you for 5. (d20 18+3 vs AC 18)');
  500 |       Game.log('A mighty blow! You hit the Skeleton for 18. (d20 20, a telling blow)');
  501 |       Game.log('The Dark Acolyte hurls a bolt of shadow at you from your left for 9. (d20 15+6 vs AC 18)');
  502 |     });
  503 |     await page.waitForTimeout(250);
  504 |     const shown = await page.evaluate(() => {
  505 |       const el = document.getElementById('log'), box = el.getBoundingClientRect();
  506 |       return [...el.children].map(d => {
  507 |         const db = d.getBoundingClientRect(), s = d.querySelector('.roll'), rb = s && s.getBoundingClientRect();
  508 |         return {
  509 |           text: d.textContent,
  510 |           whole: db.top >= box.top - 0.5 && db.bottom <= box.bottom + 0.5,
  511 |           roll: !!rb && rb.top >= db.top - 0.5 && rb.bottom <= db.bottom + 0.5 && rb.right <= box.right + 0.5,
  512 |           cut: d.scrollWidth > d.clientWidth + 1,
  513 |         };
  514 |       });
  515 |     });
  516 |     expect(shown.length, 'at least the newest two should fit').toBeGreaterThanOrEqual(2);
  517 |     // the newest line is the one being read, and it is the longest
  518 |     expect(shown[shown.length - 1].text).toContain('Dark Acolyte');
  519 |     for (const line of shown) {
  520 |       expect(line.whole, `half a line left in the panel: ${line.text}`).toBe(true);
  521 |       expect(line.cut, `a line was cut off sideways: ${line.text}`).toBe(false);
  522 |       expect(line.roll, `the roll was hidden: ${line.text}`).toBe(true);
  523 |     }
  524 |     expect(errors).toEqual([]);
  525 |   });
  526 | 
  527 |   test('a fact greets a quiet title, its first tap starts the theme, and it stays dismissed for the visit', { tag: '@mobile' }, async ({ page }) => {
  528 |     const errors = watchForErrors(page);
  529 |     await page.addInitScript(() => {
  530 |       localStorage.setItem('deepdelve.firstSeen', '1');
  531 |       localStorage.setItem('deepdelve.samples', 'on');
```