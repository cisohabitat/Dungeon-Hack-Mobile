# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: art.spec.js >> art >> a creature sways as it stands, leans into a step across the view and topples as it falls; firelight warms the side it is on; a calm view holds it upright
- Location: test/browser/art.spec.js:627:3

# Error details

```
Error: drawn leaning

expect(received).toBeGreaterThanOrEqual(expected)

Expected: >= 1
Received:    0
```

# Page snapshot

```yaml
- generic [ref=e3]:
  - log [ref=e4]:
    - paragraph [ref=e5]: Cold stone halls stretch into darkness.
    - paragraph [ref=e6]: Welcome, Thessaly the Fighter. 8 floors lie below. Find the Heart of the Mountain.
  - generic [ref=e7]:
    - generic [ref=e8]:
      - generic [ref=e9]:
        - generic [ref=e10]:
          - generic [ref=e11]: Thessaly
          - generic [ref=e12]: Fighter 1
        - generic [ref=e13]:
          - img "Life 19 of 19" [ref=e14]:
            - generic [ref=e16]: HP 19/19
          - img "Fed" [ref=e17]:
            - generic [ref=e19]: Fed
        - button "Quaff a healing draught (1 carried)" [ref=e20] [cursor=pointer]:
          - img [ref=e22]
          - generic [ref=e24]: Drink ×1
        - generic [ref=e25]:
          - generic [ref=e26]: Floor 1/8
          - generic [ref=e27]: 0 gold
          - generic [ref=e28]: W
      - generic [ref=e29]:
        - img "The dungeon. Facing west. Open floor stretches ahead." [ref=e30]
        - status
        - generic:
          - generic: Floor 1 of 8
          - generic: Grey Halls
        - generic "Open map" [ref=e31]
      - button "Message history" [ref=e32] [cursor=pointer]: ≡ Log
      - generic [ref=e34]: Welcome, Thessaly the Fighter. 8 floors lie below. Find the Heart of the Mountain.
    - generic [ref=e35]:
      - generic [ref=e36]:
        - generic [ref=e37]:
          - button "Turn left" [ref=e38] [cursor=pointer]:
            - img [ref=e40]
          - button "Forward" [ref=e43] [cursor=pointer]:
            - img [ref=e45]
          - button "Turn right" [ref=e47] [cursor=pointer]:
            - img [ref=e49]
          - button "Step left" [ref=e52] [cursor=pointer]:
            - img [ref=e54]
          - button "Back" [ref=e56] [cursor=pointer]:
            - img [ref=e58]
          - button "Step right" [ref=e60] [cursor=pointer]:
            - img [ref=e62]
        - generic [ref=e64]:
          - 'button "Attack: ready" [ref=e65] [cursor=pointer]':
            - img [ref=e67]
            - generic [ref=e76]: Attack
            - generic [ref=e77]: Ready
          - button "Use" [ref=e78] [cursor=pointer]:
            - img [ref=e80]
            - generic [ref=e85]: Use
          - 'button "Bash: break the blow in front of you and set it reeling" [ref=e86] [cursor=pointer]':
            - img [ref=e88]
            - generic [ref=e90]: Bash
      - generic [ref=e91]:
        - button "Map" [ref=e92] [cursor=pointer]
        - button "Pack" [ref=e93] [cursor=pointer]
        - button "Hero" [ref=e94] [cursor=pointer]
        - button "Journal" [ref=e95] [cursor=pointer]
        - 'button "Rest: recover up to two thirds of maximum life and spell points. Costs food; danger may interrupt." [ref=e96] [cursor=pointer]':
          - text: Rest
          - generic [ref=e97]: +⅔ life
        - button "Menu" [ref=e98] [cursor=pointer]
```

# Test source

```ts
  584 |         delete L.items[key];
  585 |         const without = await frame();
  586 |         let n = 0;
  587 |         for (let i = 0; i < withIt.length; i += 4) if (Math.abs(withIt[i] - without[i]) + Math.abs(withIt[i + 1] - without[i + 1]) + Math.abs(withIt[i + 2] - without[i + 2]) > 24) n++;
  588 |         return n;
  589 |       });
  590 |       await page.evaluate(() => {
  591 |         const L = Game.level(), p = Game.player(), [dx, dy] = Dungeon.DIRS[p.dir];
  592 |         for (const k of [1, 2, 3]) L.tiles[(p.y + dy * k) * L.w + p.x + dx * k] = Dungeon.T.FLOOR;
  593 |         L.monsters.length = 0; L.dressing = []; L.npcs = [];
  594 |       });
  595 |       expect(await page.evaluate(() => Game.player().eq.weapon.t)).toBe('shortbow');
  596 |       const behindBow = await itemPixels();
  597 |       // and the same ring with the bow put away, a bare fist low on the right
  598 |       await page.evaluate(() => { Game.player().eq.weapon = null; });
  599 |       const clear = await itemPixels();
  600 |       expect(clear, 'the ring is drawn at all').toBeGreaterThan(40);
  601 |       expect(behindBow / clear, `the bow hid ${clear - behindBow} of the ring's ${clear} pixels`).toBeGreaterThan(0.95);
  602 |       expect(errors).toEqual([]);
  603 |     });
  604 |   }
  605 |   test('candles left burning light the floor around them, a smaller pool than a torch\'s', async ({ page }) => {
  606 |     // they were drawn alight but gave no light at all
  607 |     const errors = watchForErrors(page);
  608 |     await startGame(page, { seed: 'candle-light' });
  609 |     const lit = await page.evaluate(() => {
  610 |       const room = (lights, dressing) => ({ w: 20, h: 20, lights, dressing });
  611 |       const candles = room([], [{ x: 10, y: 10, k: 'candles', ox: 0, oy: 0 }, { x: 4, y: 4, k: 'bones', ox: 0, oy: 0 }]);
  612 |       const torch = room([{ x: 10, y: 10 }], []);
  613 |       const dark = room([], [{ x: 10, y: 10, k: 'bones', ox: 0, oy: 0 }]);
  614 |       const at = (lv, x, y) => Renderer.lightOf(lv, x, y);
  615 |       return { on: at(candles, 10, 10), near: at(candles, 12, 10), far: at(candles, 14, 10), bones: at(candles, 4, 4), torch: at(torch, 10, 10), torchFar: at(torch, 14, 10), dark: at(dark, 10, 10) };
  616 |     });
  617 |     expect(lit.dark, 'bones give no light').toBe(0);
  618 |     expect(lit.bones).toBe(0);
  619 |     expect(lit.on, 'the candles\' own square is lit').toBeGreaterThan(0.5);
  620 |     expect(lit.near, 'and the squares beside them, less').toBeGreaterThan(0);
  621 |     expect(lit.near).toBeLessThan(lit.on);
  622 |     expect(lit.far, 'four squares off is dark again').toBe(0);
  623 |     expect(lit.torch, 'a torch is the brighter').toBeGreaterThan(lit.on);
  624 |     expect(lit.torchFar, 'and reaches further').toBeGreaterThan(0);
  625 |     expect(errors).toEqual([]);
  626 |   });
  627 |   test('a creature sways as it stands, leans into a step across the view and topples as it falls; firelight warms the side it is on; a calm view holds it upright', async ({ page }) => {
  628 |     const errors = watchForErrors(page);
  629 |     await startGame(page, { seed: 'sway-lit' });
  630 |     await clearBoons(page);
  631 |     expect(await faceOpenGround(page, 3)).toBeGreaterThanOrEqual(2);
  632 |     const got = await page.evaluate(async () => {
  633 |       const L = Game.level(), p = Game.player(), G = Game.state(), [dx, dy] = Dungeon.DIRS[p.dir], [sx, sy] = Dungeon.DIRS[(p.dir + 1) % 4];
  634 |       const x = p.x + dx * 2, y = p.y + dy * 2;
  635 |       for (const j of [-1, 0, 1]) L.tiles[(y + sy * j) * L.w + x + sx * j] = Dungeon.T.FLOOR;
  636 |       L.monsters.length = 0; L.dressing = []; L.items = {}; L.fields = {}; L.lights = [];
  637 |       L.monsters.push({ uid: 5, id: 'orc', x, y, hp: 99, maxHp: 99, awake: false, nextAct: 1e12, rx: x, ry: y, fromX: x, fromY: y, moveT0: 0, moveT1: 0, flashUntil: 0 });
  638 |       const wait = ms => new Promise(r => setTimeout(r, ms));
  639 |       // at rest it sways, slowly, a little
  640 |       // (read across a whole slow sway, not waited out: it takes seconds)
  641 |       const t00 = performance.now(), leans = [];
  642 |       for (let i = 0; i < 12; i++) leans.push(Game.renderState(t00 + i * 1100).sprites.find(s => s.maxHp).lean);
  643 |       await wait(300);
  644 |       const unlit = Renderer.lit.length;
  645 |       // a fire on the square to its right (the view's right): its right side is warmed
  646 |       L.fields[`${x + sx},${y + sy}`] = { k: 'fire', fuel: 'vent', until: G.t + 1e9, spread: 1e12, burn: 1e12, gen: 0 };
  647 |       await wait(300);
  648 |       const lit = Renderer.lit;
  649 |       L.fields = {};
  650 |       // a step to its right, across the view: it leans that way at the middle of it
  651 |       // (read against its sway at that same moment, which can lean it either way on its own)
  652 |       const m = L.monsters[0], t0 = performance.now();
  653 |       const still = Game.renderState(t0 + 1000).sprites.find(s => s.maxHp).lean;
  654 |       m.fromX = m.x; m.fromY = m.y; m.x += sx; m.y += sy; m.moveT0 = t0; m.moveT1 = t0 + 2000;
  655 |       const mid = Game.renderState(t0 + 1000).sprites.find(s => s.maxHp).lean - still;
  656 |       m.fromX = m.x; m.fromY = m.y; m.x -= 2 * sx; m.y -= 2 * sy; m.moveT0 = t0; m.moveT1 = t0 + 2000;
  657 |       const back = Game.renderState(t0 + 1000).sprites.find(s => s.maxHp).lean - still;
  658 |       m.moveT1 = 0; m.x += sx; m.y += sy; m.rx = m.x; m.ry = m.y;
  659 |       // (drawn leaning on some frame of a second and a half: its sway passes upright now and then)
  660 |       let leaned = 0;
  661 |       for (let i = 0; i < 10; i++) { await wait(150); leaned = Math.max(leaned, Renderer.leaned); }
  662 |       // a calm view draws it upright
  663 |       Renderer.setCalm(true); await wait(300);
  664 |       const calmLeaned = Renderer.leaned;
  665 |       Renderer.setCalm(false);
  666 |       // and the fallen topple to one side as they sink
  667 |       L.monsters.length = 0;
  668 |       const now = performance.now(), fx = Game.renderState(now).fx;
  669 |       fx.corpses.push({ x: x + 0.5, y: y + 0.5, sprite: 'orc', scale: 1, born: now, dx: 0, dy: 1, fly: 0 });
  670 |       const body = u => Game.renderState(now + u * 1100).sprites.find(s => s.alpha != null && s.sqx > 1);
  671 |       const fall = [0.05, 0.2, 0.38].map(u => Math.abs(body(u).lean));
  672 |       // down on the floor a while, then sinking away
  673 |       const lying = body(0.6), going = body(0.97);
  674 |       return { leans, unlit, lit, mid, back, leaned, calmLeaned, fall, lying: { sqy: lying.sqy, alpha: lying.alpha }, goingAlpha: going ? going.alpha : 0 };
  675 |     });
  676 |     expect(Math.max(...got.leans) - Math.min(...got.leans), 'it sways at rest').toBeGreaterThan(0.005);
  677 |     expect(Math.max(...got.leans.map(Math.abs)), 'but only a little').toBeLessThan(0.06);
  678 |     expect(got.unlit, 'with no torch and no fire near, nothing is warmed').toBe(0);
  679 |     expect(got.lit.length, 'beside the fire it is warmed').toBe(1);
  680 |     expect(got.lit[0].side, 'on its right, where the fire is').toBeGreaterThan(0.1);
  681 |     // (its waddle leans it a little one way or the other by the square it steps from; the step outweighs it)
  682 |     expect(got.mid, 'stepping to the right, it leans right').toBeGreaterThan(0.02);
  683 |     expect(got.back, 'stepping to the left, it leans left').toBeLessThan(-0.02);
> 684 |     expect(got.leaned, 'drawn leaning').toBeGreaterThanOrEqual(1);
      |                                         ^ Error: drawn leaning
  685 |     expect(got.fall[2], 'falling, it topples further and further').toBeGreaterThan(got.fall[1]);
  686 |     expect(got.fall[1]).toBeGreaterThan(got.fall[0]);
  687 |     expect(got.fall[2], 'well over by the time it lands').toBeGreaterThan(0.6);
  688 |     expect(got.lying.sqy, 'it lies low on the floor').toBeLessThan(0.4);
  689 |     expect(got.lying.alpha, 'still there, not yet fading').toBeGreaterThan(0.95);
  690 |     expect(got.goingAlpha, 'then sinks away').toBeLessThan(0.2);
  691 |     expect(got.calmLeaned, 'a calm view draws nothing leaning').toBe(0);
  692 |     expect(errors).toEqual([]);
  693 |   });
  694 |   test('a creature standing on a pile of things is drawn in front of all of it', async ({ page }) => {
  695 |     // a gem scattered to the near side of its square came out over the orc standing on it
  696 |     const errors = watchForErrors(page);
  697 |     await page.addInitScript(() => localStorage.setItem('deepdelve.tipsOff', '1'));
  698 |     await startGame(page, { seed: 'pile-under' });
  699 |     await clearBoons(page);
  700 |     expect(await faceOpenGround(page, 2)).toBeGreaterThanOrEqual(1);
  701 |     const order = await page.evaluate(async () => {
  702 |       const L = Game.level(), p = Game.player(), [dx, dy] = Dungeon.DIRS[p.dir], x = p.x + dx, y = p.y + dy;
  703 |       L.monsters.length = 0; L.dressing = []; L.items = {};
  704 |       L.items[x + ',' + y] = ['gem', 'potion_heal', 'dagger', 'ration', 'gold'].map(t => (t === 'gem' ? { t, q: 50, name: 'Garnet' } : { t, q: t === 'gold' ? 10 : 1 }));
  705 |       L.monsters.push({ uid: 5, id: 'orc', x, y, hp: 99, maxHp: 99, awake: true, nextAct: 1e12, rx: x, ry: y, fromX: x, fromY: y, moveT0: 0, moveT1: 0, flashUntil: 0 });
  706 |       await new Promise(r => setTimeout(r, 300));
  707 |       return Renderer.order;
  708 |     });
  709 |     expect(order.filter(k => k === 'floor').length, 'the pile is drawn').toBeGreaterThanOrEqual(5);
  710 |     expect(order[order.length - 1], 'the orc last, over everything under it').toBe('stand');
  711 |     expect(errors).toEqual([]);
  712 |   });
  713 | });
  714 | 
  715 | test('refined bestiary sprites retain readable blink and unclipped raised equipment', async ({ page }) => {
  716 |   const errors = watchForErrors(page);
  717 |   await page.goto('/');
  718 |   await artReady(page, { hound: ['special'], lizardfolk: ['windup'], dwarf_arbalest: ['windup', 'special'], wyrm: ['windup', 'special'], drow_mage: ['windup', 'special'] });
  719 |   const result = await page.evaluate(() => {
  720 |     const solid = s => {
  721 |       const c = s.levels[0], data = c.getContext('2d').getImageData(0, 0, c.width, c.height).data;
  722 |       let count = 0, top = c.height, bottom = 0;
  723 |       for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (data[(y * c.width + x) * 4 + 3] > 128) { count++; top = Math.min(top, y); bottom = Math.max(bottom, y); }
  724 |       return { count, top, bottom };
  725 |     };
  726 |     const hound = Assets.sprites.hound;
  727 |     return { idle: solid(hound), blink: solid(hound.special), spear: solid(Assets.sprites.lizardfolk.windup),
  728 |       champion: ['skarrow', 'vaelith'].map(id => {
  729 |         const base = Assets.sprites[MONSTERS[id].sprite], own = base.elite[id];
  730 |         return { id, distinct: own.url !== base.url, windup: own.windup.url !== own.url, special: own.special.url !== own.url };
  731 |       }) };
  732 |   });
  733 |   expect(result.blink.count).toBeGreaterThan(result.idle.count * 0.25);
  734 |   expect(result.blink.bottom).toBeGreaterThan(result.idle.bottom - 8);
  735 |   expect(result.spear.top, 'the raised spearhead has transparent space above its point').toBeGreaterThan(2);
  736 |   for (const c of result.champion) expect(c).toEqual({ id: c.id, distinct: true, windup: true, special: true });
  737 |   expect(errors).toEqual([]);
  738 | });
  739 | 
```