'use strict';
// Headless playtest: loads the real game rules and plays full runs with a bot,
// so balance can be measured instead of guessed at.
const { loadGame } = require('./harness');

const BACKGROUND_ROTATION = ['oathbroken', 'tombwise', 'ashborn', 'cloistered', 'deepborn', 'debtor'];

const TICK = 300;   // ms of game time per bot action, roughly a brisk human pace
// DUAL=1 plays the fighter with a blade in each hand instead of a shield, so the
// two builds can be compared over the same seeds rather than argued about.
const DUAL = process.env.DUAL === '1';
const SMART = process.env.SMART !== '0';
const ENC = process.env.ENC !== '0';
// EXPLORE=0.8 sweeps each floor before taking the stairs: every reachable item
// pile, and walking until that share of the floor has been in view. The plain
// bot heads straight down, which is not how people play, and a class balance
// tuned only against it rewards fragility that thorough play then punishes.
const EXPLORE = parseFloat(process.env.EXPLORE || '0');
// HEROPATH=knight (or any class path) forces that path when it is offered;
// otherwise the runs alternate paths. Backgrounds also rotate by run index,
// so compare forced paths on identical inputs before attributing a gap to one.
// (Not PATH: that would take the shell's own with it.)
const HEROPATH = process.env.HEROPATH || '';

function run(ctx, cls, seed, opts, bg, idx) {
  const { Rng, Dice } = ctx;
  // Live events roll two ways: the shared Dice, seeded from the clock when the
  // module loads, and bare Math.random. Neither is reproducible, so two
  // benchmark passes never saw the same fight and comparing them measured
  // noise. Seed both from the run's own identity, and a tuning change becomes
  // the only thing that can differ between two passes.
  const key = `${seed}|${cls}|${bg}`;
  const loose = new Rng(key + '|loose');
  const realRandom = Math.random;
  Dice.s = new Rng(key).s;
  Math.random = () => loose.next();
  try {
    const rec = play(ctx, cls, seed, opts, bg, idx);
    // FP=1 prints a fingerprint of the whole run as it ended: the state and every
    // line logged. A change meant to alter nothing (moving code between files)
    // must leave every fingerprint as it was.
    if (process.env.FP) {
      const G = ctx.Game.state();
      // (all but the wall-clock moment the run began, which no two passes share)
      const h = require('crypto').createHash('md5').update(JSON.stringify({ ...G, created: 0 })).update(JSON.stringify(G.log)).digest('hex').slice(0, 16);
      console.log(`FP ${cls} ${seed} ${bg} ${h} t=${G.t} logSeq=${G.logSeq}`);
      // FP=keys prints one hash a key of the state too, to find which part moved
      if (process.env.FP === 'keys') for (const k of Object.keys(G)) console.log(`FPK ${cls} ${seed} ${k} ${require('crypto').createHash('md5').update(JSON.stringify(G[k]) || 'u').digest('hex').slice(0, 10)}`);
    }
    return rec;
  } finally {
    Math.random = realRandom;
  }
}

function play(ctx, cls, seed, opts, bg, idx) {
  const { Game, Dungeon, ITEMS, RELICS, MONSTERS, ELEMENTS_TAKEN, MAX_LEVEL, XP_TABLE } = ctx;
  const T = Dungeon.T;
  // FIT=1 does what the creation screen does: the best roll goes in the class's key stat
  const stats = Game.rollStats();
  if (process.env.FIT) {
    const key = ctx.CLASSES[cls].primary;
    const best = Object.keys(stats).reduce((a, b) => (stats[b] > stats[a] ? b : a), key);
    [stats[key], stats[best]] = [stats[best], stats[key]];
  }
  // SHADE=n: a hero fell on floor n of an earlier run, so this one finds
  // their shade there; the classes of the fallen take turns
  if (process.env.SHADE) {
    const fell = ['fighter', 'cleric', 'mage', 'thief', 'ranger'][idx % 5];
    ctx.store.set('deepdelve.fallen', JSON.stringify({ name: 'Old', cls: fell, level: 5, depth: Number(process.env.SHADE), run: 'bench', gear: [{ t: 'longsword', q: 1, e: 1 }] }));
  }
  // WICK=n: Wick has met n of this player's heroes before, so from the third it
  // asks a regular a tenth less (each run's store is otherwise fresh: a first meeting)
  if (process.env.WICK) ctx.store.set('deepdelve.progress', JSON.stringify({ wick: { met: Number(process.env.WICK), told: 0, won: 0, last: null } }));
  Game.newGame({ name: 'Bot', cls, bg, stats, seed, opts });
  // Measuring the build, not the drop rate: without this only about a third of
  // runs happen to find a light blade, and the comparison mostly reports how
  // often loot obliged.
  if (DUAL && Game.canDualWield()) Game.player().inv.push({ t: 'shortsword', q: 1, e: 0 });
  // NORELIC=1 plays the same run with no relics in it, to measure what they add
  if (process.env.NORELIC) { Game.state().relics.floor = {}; Game.state().relics.shop = []; }
  let now = 0;
  const G = Game.state();
  const p = Game.player();
  const rec = { cls, bg, seed, depth: 1, deepest: 1, died: false, won: false, cause: '', ticks: 0, kills: 0, potionsDrunk: 0, rests: 0, starved: 0, packFull: 0, goldFound: 0, hpLow: 0 };
  const fieldsCounted = new WeakSet();   // the floors counted in fieldsSeen

  // BFS from the player over passable tiles, returning a distance field
  const field = (L, tx, ty, treatDoorsOpen, colors) => {
    const dist = new Int32Array(L.w * L.h).fill(-1);
    const solidNpc = new Set((L.npcs || []).map(n => n.y * L.w + n.x).filter(i => i !== ty * L.w + tx));
    const q = [ty * L.w + tx];
    dist[q[0]] = 0;
    for (let qi = 0; qi < q.length; qi++) {
      const i = q[qi], x = i % L.w, y = (i / L.w) | 0;
      for (const [dx, dy] of Dungeon.DIRS) {
        const nx = x + dx, ny = y + dy;
        if (nx < 0 || ny < 0 || nx >= L.w || ny >= L.h) continue;
        const ni = ny * L.w + nx;
        if (dist[ni] >= 0) continue;
        const t = L.tiles[ni];
        if (solidNpc.has(ni)) continue;
        if (t === T.FLOOR || t === T.DOOR_OPEN || t === T.DOOR || (t === T.DOOR_LOCKED && (treatDoorsOpen || (colors && colors.has(L.locks[nx + ',' + ny] || 'brass'))))) { dist[ni] = dist[i] + 1; q.push(ni); }
      }
    }
    return dist;
  };

  // a mimic still shut is a barrel to the bot as to a player, until it has creaked
  const shown = m => !(m.disguised && !m.creaked);
  const snap = () => {
    const L = Game.level();
    let adj = 0, near = 0;
    for (const m of L.monsters) {
      const d = Math.abs(m.x - p.x) + Math.abs(m.y - p.y);
      if (d <= 1) adj++;
      if (m.awake && d <= 4) near++;
    }
    return { adj, near, awake: L.monsters.filter(m => m.awake).length, total: L.monsters.length };
  };
  // Advance to the next moment worth acting in: a whole tick normally, but no
  // further than the instant the hero can swing or cast again, the way a
  // player holding Attack strikes the moment the blow is ready. Rounding
  // every action up to a whole 300ms tick made a 400ms dagger take 600ms,
  // favoured slow weapons over fast ones, and hid the dual-wield swing cost
  // entirely: a 700ms and an 805ms swing both came out at 900ms.
  const step = () => {
    // Only the explicit puzzle benchmark answers catches. Read the same marks
    // shown to a player, at their current square; no navigation or combat rule changes.
    if (process.env.PUZZLES === 'solve') {
      const q = Game.level().puzzle;
      if (q && !q.solved && q.x === p.x && q.y === p.y && G.status === 'playing') {
        Game.input('use');
        if (Game.currentPuzzle()) {
          // A catch holds coins, not the ignored gear lying beside them.
          const original = new Set(Game.floorItems()), held = Game.floorItems().filter(it => it.puzzle);
          Game.puzzleAction('reset');
          const marks = q.kind === 'runes' ? q.order : q.kind === 'torches' ? [0, 1, 2, 3].filter(i => q.target & (1 << i)) : [q.order[0]];
          for (const mark of marks) Game.puzzleAction('mark', mark);
          if (!Game.puzzleAction('submit')) throw new Error('The puzzle benchmark could not release a catch.');
          const offers = Game.puzzleOffers ? Game.puzzleOffers() : [];
          const desired = process.env.PUZZLE_REWARD || 'gold';
          const offer = offers.find(o => o.id === desired) || offers.find(o => o.id === 'gold');
          if (offer && !Game.puzzleAction('claim', offer.id)) throw new Error('The puzzle benchmark could not choose its reward.');
          // Collect the chosen share only, never gear the normal walker ignored.
          const reward = offer && offer.id !== 'gold' ? Game.floorItems().filter(it => !original.has(it)) : held;
          Game.closePuzzle();
          for (const it of reward) Game.takeItem(it);
          if (offer) {
            rec.puzzleRewards = rec.puzzleRewards || {}; rec.puzzleRewards[offer.id] = (rec.puzzleRewards[offer.id] || 0) + 1;
          }
          rec.puzzlesSolved = (rec.puzzlesSolved || 0) + 1;
        }
      }
    }
    const wait = p.nextAttack - G.t;
    const dt = wait > 0 && wait < TICK ? Math.max(16, Math.ceil(wait)) : TICK;
    Game.update(now, dt);
    // FPTRACE=1 prints each line logged as it is said, with the game's clock, to find where two passes part
    if (process.env.FPTRACE) { const n = (G.logSeq || 0) - (step.seen || 0); for (const e of G.log.slice(-Math.min(n, G.log.length))) if (n > 0) console.log(`TR ${G.t} ${e.m}`); step.seen = G.logSeq; }
  };
  // STUCKAT=1 keeps the last moves made, to show what a run that ran out of time was doing
  const trace = [];
  if (process.env.STUCKAT) for (const k of ['input', 'castSpell', 'useItem', 'rest', 'useAbility']) {
    const f = Game[k];
    Game[k] = (...a) => { trace.push(`${rec.ticks} f${G.depth} ${p.x},${p.y} d${p.dir} ${k}(${a.map(x => typeof x === 'object' ? (x && (x.t || x.id)) || '?' : x).join(',')}) line ${(/playtest\.js:(\d+)/.exec(new Error().stack.split('\n')[2] || '') || [])[1]}`); if (trace.length > 60) trace.shift(); return f(...a); };
  }
  while (rec.ticks < 80000 && G.status === 'playing') {
    rec.ticks++;
    // DETAIL=1: note the hero's state on arriving at each floor (read-only, no dice)
    if (rec._lastDepth !== G.depth) {
      rec._lastDepth = G.depth;
      (rec.arrive = rec.arrive || {})[G.depth] = { lvl: p.level, maxHp: p.maxHp, hp: p.hp, pots: p.inv.filter(i => i.t === 'potion_heal' || i.t === 'potion_xheal').reduce((a, i) => a + (i.q || 1), 0), gold: p.gold, t: G.t };
    }
    // the floor the top level was reached on, for how long the hero went on past it
    if (p.level >= MAX_LEVEL && !rec.topAt) rec.topAt = G.depth;
    // the floor the path's legend fell on (a champion down after the path was taken)
    if (!rec.legendAt && G.relics && G.relics.found.some(id => RELICS[id] && RELICS[id].legend)) rec.legendAt = G.depth;
    if (p.hp <= p.maxHp * 0.5) { const s2 = snap(); rec.lastAdj = s2.adj; rec.lastNear = s2.near; rec.lastAwake = s2.awake; rec.lastTotal = s2.total; }
    now += TICK;
    // experience offers a choice on every level; take the most useful one
    while (Game.pendingBoons()) {
      const offer = Game.pendingBoons();
      // a path: the one asked for, or each in turn run by run
      if (Game.isPathOffer(offer)) {
        // HEROPATH=none walks past the offer, to measure what the paths add
        if (HEROPATH === 'none') { Game.state().pendingBoons.shift(); Game.state().pendingLevels.shift(); continue; }
        rec.path = offer.includes(HEROPATH) ? HEROPATH : offer[idx % offer.length];
        rec.pathAt = G.depth;
        Game.chooseBoon(rec.path);
        continue;
      }
      // a capstone: each of the two in turn, by pairs of runs so that it does not follow the path's turn;
      // HEROCAP=none walks past it, to measure what the capstones add
      if (Game.isCapstoneOffer(offer)) {
        if (process.env.HEROCAP === 'none') { Game.state().pendingBoons.shift(); Game.state().pendingLevels.shift(); continue; }
        rec.capstone = offer.includes(process.env.HEROCAP) ? process.env.HEROCAP : offer[Math.floor(idx / 2) % offer.length];
        rec.capAt = G.depth;
        Game.chooseBoon(rec.capstone);
        continue;
      }
      // a talent by what a sensible player of each class would reach for first
      const order = ['second_wind', 'weapon_master', 'bulwark', 'stand_firm', 'cleave', 'riposte', 'shield_slam',
        'last_rites', 'healing_hands', 'sanctified', 'warding_light', 'zeal', 'radiance',
        'empower', 'mirror_image', 'arcane_flow', 'quick_words', 'kindling', 'rime',
        'lucky', 'assassinate', 'venom', 'choking_cloud', 'evasion', 'light_fingers', 'shadow_step',
        'eagle_eye', 'hunters_mark', 'swift_quiver', 'volley', 'long_snare', 'field_craft', 'camouflage',
        'thick_hide', 'barkskin', 'rending_claws', 'green_hands', 'beast_bond', 'stormborn', 'long_thorns',
        'opener', 'vigor', 'keen', 'swift', 'spread', 'hardy', 'nose', 'unheld', 'trapsense', 'focus', 'wayfinder',
        // past the top level, renown
        'r_keen', 'r_vigor', 'r_steady', 'r_swift', 'r_quick', 'r_mend', 'r_well'];
      // a ranger's blows go by Dexterity: Strength lessons are nothing to one
      const pick = order.find(id => offer.includes(id) && !(cls === 'ranger' && id === 'str')) || offer[0];
      // Self-Taught: both points in the class's key score, then (its two given) in Constitution
      const key = { fighter: 'str', cleric: 'wis', mage: 'int', thief: 'dex', ranger: 'dex', druid: 'wis' }[cls];
      const room = k => ((Game.player().taught || {})[k] || 0) === 0;
      const to = room(key) ? key : room('con') ? 'con' : 'dex';
      Game.chooseBoon(pick, pick === 'spread' ? [to, to] : undefined);
      rec.boons = (rec.boons || 0) + 1;
    }
    const L = Game.level();
    const hpFrac = p.hp / p.maxHp;
    if (hpFrac < 0.3) rec.hpLow++;

    // --- use the class's own kit before its consumables. The bot used to cast
    // only attack spells, so a cleric never healed and a mage never raised
    // Shield, and the class comparison measured a player who ignored half of
    // what each class is for. SMART=0 plays the old way, to compare.
    if (SMART) {
      // casting shares the swing timer, so only try when ready
      const castable = G.t < p.nextAttack ? [] : Game.knownSpells().filter(sp => Game.spellAvailable(sp) && p.sp >= Game.spellCost(sp) && !Game.spellWasteReason(sp));
      const healSp = castable.filter(sp => sp.kind === 'heal').pop();
      // a druid takes the bear when a fight comes close, and keeps it: any other spell would let it go
      const closeBy = L.monsters.some(m => m.awake && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 3);
      // out of the bear, a druid's roots break off a blow being drawn back beside them, or hold a
      // foe while they mend; asked before the bear, which would take the points (NOROOT=1 never)
      const rootSp = !process.env.NOROOT && G.t >= p.nextAttack && !Game.shaped() && Game.knownSpells().find(sp => sp.kind === 'root' && Game.spellAvailable(sp) && p.sp >= Game.spellCost(sp));
      if (rootSp) {
        const dir = Dungeon.DIRS.findIndex(([dx, dy]) => L.monsters.some(m => m.x === p.x + dx && m.y === p.y + dy && !(m.snaredUntil > G.t) && !(m.windup && m.windup.move === 'rite') && (m.windup || hpFrac < 0.6)));
        if (dir >= 0) { p.dir = dir; if (Game.castSpell(rootSp) !== false) { rec.roots = (rec.roots || 0) + 1; step(); continue; } }
      }
      const shape = !process.env.NOSHAPE && castable.find(sp => sp.kind === 'shape');
      if (shape && closeBy) { Game.castSpell(shape); rec.shapes = (rec.shapes || 0) + 1; step(); continue; }
      if (hpFrac < 0.5 && healSp && !process.env.NOHEAL && !Game.shaped()) { Game.castSpell(healSp); rec.healsCast = (rec.healsCast || 0) + 1; step(); continue; }
      // a fight is about to start: raise defences first, keeping points in hand
      const closing = L.monsters.some(m => m.awake && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 3);
      const buff = closing && !process.env.NOBUFF && castable.find(sp => sp.kind === 'buff' && p.sp >= Game.spellCost(sp) + 2);
      if (buff) { Game.castSpell(buff); rec.buffsCast = (rec.buffsCast || 0) + 1; step(); continue; }
    }
    // --- emergency: drink a healing potion
    const heal = p.inv.find(i => i.t === 'potion_heal' || i.t === 'potion_xheal');
    if (hpFrac < 0.35 && heal) { Game.useItem(heal); rec.potionsDrunk++; step(); continue; }
    // --- a charm in the pack goes on the companion (the fang first; a sellsword's whetstone before
    // anything, in place of what it wears), unless NOCHARM=1
    if (!process.env.NOCHARM && Game.companionHere()) {
      const c = Game.companion(), hired = c.kind === 'sellsword';
      const whet = hired && c.charm !== 'charm_whetstone' && p.inv.find(i => i.t === 'charm_whetstone');
      const ch = whet || (!c.charm && (p.inv.find(i => i.t === 'charm_fang') || p.inv.find(i => ITEMS[i.t].kind === 'charm' && i.t !== 'charm_whetstone')));
      if (ch && !Game.giveCharm(ch)) rec.charms = (rec.charms || 0) + 1;
    }
    // (how much the elements are at work: the floors this run on which something was left burning, frozen or spilt)
    if (L.fields && Object.keys(L.fields).length && !fieldsCounted.has(L)) { fieldsCounted.add(L); rec.fieldsSeen = (rec.fieldsSeen || 0) + 1; }
    // --- standing in fire: step out of it first (as anyone would), to a square not burning
    {
      const burning = (x, y) => { const f = Game.fieldAt ? Game.fieldAt(x, y) : null; return !!f && f.k === 'fire'; };
      if (burning(p.x, p.y) && !(p.held > G.t)) {
        const k = [0, 1, 2, 3].find(k => { const [dx, dy] = Dungeon.DIRS[k], x = p.x + dx, y = p.y + dy, t = L.tiles[y * L.w + x];
          return (t === T.FLOOR || t === T.DOOR_OPEN) && !burning(x, y) && !(L.dressing || []).some(q => q.x === x && q.y === y && ['barrel', 'crate', 'urn', 'oilcask'].includes(q.k)) && !L.monsters.some(o => o.x === x && o.y === y) && !(L.npcs || []).some(o => o.x === x && o.y === y); });
        if (k !== undefined) { Game.input(['forward', 'strafeR', 'back', 'strafeL'][(k - p.dir + 4) % 4]); rec.fireSteps = (rec.fireSteps || 0) + 1; step(); continue; }
      }
    }
    // --- rock about to come down on a floor of tremors: step off its mark, to a square it will not fall on
    {
      // (and a smouldering floor's crack glowing toward a flare: the squares it will cover)
      const falls = [...((L.quake && L.quake.falls) || []), ...(Game.vents ? Game.vents().flatMap(v => v.area) : [])];
      const under = (x, y) => falls.some(f => f.x === x && f.y === y);
      if (under(p.x, p.y) && !(p.held > G.t)) {
        const k = [0, 1, 2, 3].find(k => { const [dx, dy] = Dungeon.DIRS[k], x = p.x + dx, y = p.y + dy, t = L.tiles[y * L.w + x];
          return (t === T.FLOOR || t === T.DOOR_OPEN) && !under(x, y) && !(L.dressing || []).some(q => q.x === x && q.y === y && ['barrel', 'crate', 'urn', 'oilcask'].includes(q.k)) && !L.monsters.some(o => o.x === x && o.y === y) && !(L.npcs || []).some(o => o.x === x && o.y === y); });
        if (k !== undefined) { Game.input(['forward', 'strafeR', 'back', 'strafeL'][(k - p.dir + 4) % 4]); rec.rockSteps = (rec.rockSteps || 0) + 1; step(); continue; }
      }
    }
    // --- a puffcap close by: fire on the blade sears its spores, so a coat of
    // anything else is wiped for fire oil if there is some (NOPUFF=1 plays without)
    const puffNear = !process.env.NOPUFF && p.cls !== 'druid' && L.monsters.some(m => m.id === 'puffcap' && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 4);
    if (puffNear && p.eq.weapon && !Game.shaped() && !process.env.NOOIL && !(p.coating && p.coating.t === 'fire')) {
      const fire = p.inv.find(i => ITEMS[i.t].kind === 'oil' && ITEMS[i.t].coat === 'fire');
      if (fire) { Game.useItem(fire); rec.oils = (rec.oils || 0) + 1; rec.puffAnswers = (rec.puffAnswers || 0) + 1; step(); continue; }
    }
    // --- a fight is starting: coat the weapon (silver for the dead), unless NOOIL=1
    if (!p.coating && p.eq.weapon && !process.env.NOOIL) {
      const near = L.monsters.filter(m => m.awake && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 4);
      const oils = p.inv.filter(i => ITEMS[i.t].kind === 'oil');
      const undead = near.some(m => Game.mstat(m).undead);
      // (frost for what the cold bites, a Warden's blade, or a foe standing in water; fire otherwise)
      const coldBites = near.some(m => ['emberling', 'heartforged', 'wyrm', 'basilisk'].includes(m.id) || Game.wet(m.x, m.y));
      const want = undead ? 'silver' : coldBites || p.path === 'warden' ? 'frost' : 'fire';
      const oil = near.length && (oils.find(i => ITEMS[i.t].coat === want) || oils.find(i => ITEMS[i.t].coat !== 'silver' && (undead || ITEMS[i.t].coat !== 'frost' || !near.some(m => Game.mstat(m).undead))) || (undead && oils[0]));
      if (oil) { Game.useItem(oil); rec.oils = (rec.oils || 0) + 1; step(); continue; }
    }
    // --- eat when hungry
    if (p.food < 25) {
      const food = p.inv.find(i => ITEMS[i.t].kind === 'food');
      if (food) { Game.useItem(food); step(); continue; }
      else rec.starved++;
    }
    // --- stuck in something cursed: read the scroll that breaks it, if known
    if (Object.values(p.eq).some(i => i && i.curse)) {
      rec.cursedTicks = (rec.cursedTicks || 0) + 1;
      const sc = p.inv.find(i => i.t === 'scroll_uncurse' && Game.isKnown(i.t));
      if (sc) { Game.useItem(sc); rec.uncursed = (rec.uncursed || 0) + 1; step(); continue; }
    }
    // --- a mage with a focus to hold puts the staff away for a one-handed weapon, as a person would
    if (p.cls === 'mage' && !p.eq.shield && p.eq.weapon && ITEMS[p.eq.weapon.t].twoHanded) {
      const focus = p.inv.find(i => ITEMS[i.t].focus === 'mage' && !(i.curse && !i.h));
      const blade = focus && p.inv.filter(i => ITEMS[i.t].kind === 'weapon' && !ITEMS[i.t].twoHanded && !Game.canEquip(i) && !ITEMS[i.t].range)[0];
      if (blade && Game.equip(blade, true)) Game.equip(focus, true);
    }
    // Explicit audit policy: wear the earned Mythic, without changing ordinary decisions.
    if (process.env.MYTHIC === 'trial') for (const it of p.inv.slice()) if (it.u && RELICS[it.u].mythic) Game.equip(it, true);
    // --- equip anything better that we can use
    for (const it of p.inv.slice()) {
      const b = ITEMS[it.t];
      if (b.kind !== 'weapon' && b.kind !== 'armor' && b.kind !== 'shield') continue;
      if (Game.canEquip(it) || (it.curse && !it.h)) continue;
      // a focus in hand is worth more to a mage than the staff's swing
      if (b.twoHanded && p.eq.shield && ITEMS[p.eq.shield.t].focus) continue;
      const cur = p.eq[b.kind];
      const val = x => {
        if (!x) return 0;
        const bx = ITEMS[x.t];
        // a relic's powers are worth something: about a point of armour, or a
        // sixth more damage, each (swift is counted where it acts, on the swing)
        const powers = x.u ? RELICS[x.u].powers : [];
        const e = x.h ? 0 : (x.e || 0);      // no peeking at a quality still hidden
        // the legend made for the hero's path goes on, whatever its numbers: it is what the run is built round
        if (x.u && process.env.MYTHIC === 'trial' && RELICS[x.u].mythic) return 1001;
        if (x.u && RELICS[x.u].legend) return 1000;
        // a robe's spell points are worth something to a mage too: two of them about a point of armour
        // a focus is worth about its tier: a Spellbook or a Holy Symbol no more than a shield, a Reliquary more
        // (and a relic beats a plain piece of its kind, as a player would wear it for its name)
        if (bx.focus) return 1 + bx.tier * 0.5 + powers.length + (x.u ? 2 : 0);
        if (b.kind !== 'weapon') return bx.ac + e + powers.length + (bx.sp || 0) / 2 + (bx.cheap ? 1 : 0) + (x.u ? 2 : 0);
        const speed = bx.speed * (powers.includes('swift') ? 0.85 : 1);
        // a ranger reads the pack's own figure, as a player would: it counts the bow's aim
        const dps = p.cls === 'ranger' ? Game.blowRate(x) : (bx.dmg[0] * (bx.dmg[1] + 1) / 2 + bx.dmg[2] + e) / (speed / 1000);
        return dps * (bx.range ? (process.env.MELEE && p.cls === process.env.MELEE ? 0.5 : 1.5) : 1) * (1 + powers.filter(k => k !== 'swift').length / 6);   // reach is worth paying for
      };
      if (val(it) > val(cur)) Game.equip(it, true);
    }
    // --- a ring or an amulet goes on while there is a finger or a throat free
    // for it, known or not, as a person would try one: unless it is known to be cursed
    if (!process.env.NOJEWELS) for (const it of p.inv.slice()) {
      const b = ITEMS[it.t];
      if ((b.kind !== 'ring' && b.kind !== 'amulet') || (it.curse && !it.h)) continue;
      // (a legend at the throat takes the place of whatever hangs there)
      if (process.env.MYTHIC === 'trial' && p.eq.amulet?.u && RELICS[p.eq.amulet.u].mythic && b.kind === 'amulet') continue;
      const free = b.kind === 'ring' ? !p.eq.ring || !p.eq.ring2 : !p.eq.amulet || (it.u && RELICS[it.u].legend && !(p.eq.amulet.curse));
      if (free && Game.equip(it, true)) rec.jewels = (rec.jewels || 0) + 1;
    }
    // --- a cloak goes on over everything: Protection for choice, any other over none
    {
      const rank = x => (x ? (x.t === 'cloak_protect' ? 2 : 1) : 0);
      const best = p.inv.filter(i => ITEMS[i.t].kind === 'cloak').sort((a, b) => rank(b) - rank(a))[0];
      if (best && rank(best) > rank(p.eq.cloak)) Game.equip(best, true);
    }
    // --- keep room in the pack: a person drops gear they cannot use or have
    // bettered, rather than walking past everything once the pack is full
    if (p.inv.length >= Game.INV_MAX - 1) {
      const worth = x => { const bx = ITEMS[x.t], e = x.h ? 0 : (x.e || 0); return bx.kind === 'weapon' ? (bx.dmg[0] * (bx.dmg[1] + 1) / 2 + bx.dmg[2] + e) / (bx.speed / 1000) : (bx.ac || 0) + e; };
      const junk = p.inv.find(it => {
        const b = ITEMS[it.t];
        if (it.u) return false;                           // a relic is worth more than its numbers
        if (it.curse && !it.h) return true;               // known to be cursed: never wear it
        if (it.t === 'key') return !Object.values(L.locks || {}).includes(it.color);   // nothing left here it opens
        if (!['weapon', 'armor', 'shield'].includes(b.kind)) return false;
        if (Game.canEquip(it)) return true;
        const cur = p.eq[b.kind];
        return !!cur && worth(it) <= worth(cur) && !(DUAL && !Game.offhandReason(it));
      });
      if (junk) { Game.dropItem(junk); rec.dropped = (rec.dropped || 0) + 1; }
    }
    // --- a second blade, when this bot is playing that build
    if (DUAL && Game.canDualWield()) {
      let best = null, bestDps = 0;
      for (const it of p.inv.slice()) {
        if (Game.offhandReason(it)) continue;
        const bx = ITEMS[it.t];
        const dps = (bx.dmg[0] * (bx.dmg[1] + 1) / 2 + bx.dmg[2] + (it.e || 0)) / (bx.speed / 1000);
        if (dps > bestDps) { bestDps = dps; best = it; }
      }
      const cur = p.eq.offhand;
      const curDps = cur ? (ITEMS[cur.t].dmg[0] * (ITEMS[cur.t].dmg[1] + 1) / 2 + ITEMS[cur.t].dmg[2] + (cur.e || 0)) / (ITEMS[cur.t].speed / 1000) : 0;
      if (best && bestDps > curDps) Game.equip(best, true, 'offhand');
    }

    // --- answer a monster's trick the way a watchful player does: step out
    // of a smash or a storm of cold fire, out of the line of a charge or a
    // web. NOREACT=1 plays as if the violet mark meant nothing.
    if (!process.env.NOREACT) {
      // held in a web: burn it away with fire if a fire spell is to hand
      if (p.webbed > G.t && !process.env.OLDANSWERS && G.t >= p.nextAttack) {
        const fire = Game.knownSpells().find(sp => sp.fire && Game.spellAvailable(sp) && p.sp >= Game.spellCost(sp));
        if (fire && Game.castSpell(fire) !== false) { rec.burned = (rec.burned || 0) + 1; step(); continue; }
      }
      // a fighter bashes the trick (or, when hurt, the blow) being drawn back
      // beside it; a hurt thief throws smoke and strikes from it. NOABIL=1 plays without either.
      if (!process.env.NOABIL && Game.abilityOf() && !Game.abilityLeft()) {
        const near = L.monsters.filter(m => m.awake && !m.collapsed && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) === 1);
        if (p.cls === 'fighter') {
          const foe = near.find(m => m.windup && ((m.windup.move && m.windup.move !== 'rite') || hpFrac < 0.5));
          if (foe) {
            p.dir = Dungeon.DIRS.findIndex(([dx, dy]) => dx === foe.x - p.x && dy === foe.y - p.y);
            if (Game.useAbility()) { rec.abilities = (rec.abilities || 0) + 1; step(); continue; }
          }
        } else if (p.cls === 'thief' && near.length && (hpFrac < 0.45 || near.length >= 2) && !near.some(m => MONSTERS[m.id].boss)) {
          if (Game.useAbility()) { rec.abilities = (rec.abilities || 0) + 1; step(); continue; }
        } else if (p.cls === 'ranger') {
          // a ranger snares what is drawing back beside them, or what comes at them down a corridor
          let dir = -1;
          const adjWind = near.find(m => m.windup && m.windup.move !== 'rite');
          if (adjWind) dir = Dungeon.DIRS.findIndex(([dx, dy]) => dx === adjWind.x - p.x && dy === adjWind.y - p.y);
          else for (let k = 0; k < 4 && dir < 0 && !near.length; k++) {
            const [dx, dy] = Dungeon.DIRS[k];
            for (let i = 2; i <= 5; i++) {
              const x = p.x + dx * i, y = p.y + dy * i, t = L.tiles[y * L.w + x];
              if (t !== T.FLOOR && t !== T.DOOR_OPEN) break;
              const mm = L.monsters.find(o => o.x === x && o.y === y);
              if (mm) { if (mm.awake && !(mm.snaredUntil > G.t) && i <= 3) dir = k; break; }
            }
          }
          if (dir >= 0) { p.dir = dir; if (Game.useAbility()) { rec.abilities = (rec.abilities || 0) + 1; step(); continue; } }
        }
      }
      // a chant, the lich's rite, a war-horn, the Warlord's drum or a grey dwarf's swelling is answered by striking it, not by stepping away
      const trick = L.monsters.find(m => m.windup && m.windup.move && !['mend', 'rite', 'rally', 'drum', 'enlarge'].includes(m.windup.move) && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 5);
      // a gaze is answered by looking away, and then by not looking back until it has passed
      if (trick && (trick.windup.move === 'gaze' || trick.windup.move === 'dazzle')) {
        const faces = dir => { const [ax, ay] = Dungeon.DIRS[dir], [bx, by] = Dungeon.DIRS[(dir + 1) % 4]; const dx = trick.x - p.x, dy = trick.y - p.y, f = dx * ax + dy * ay; return f > 0 && Math.abs(dx * bx + dy * by) <= f; };
        if (faces(p.dir)) { Game.input(!faces((p.dir + 3) % 4) ? 'left' : 'right'); rec.dodges = (rec.dodges || 0) + 1; }
        step();
        continue;
      }
      // the other answers a player learns from the bestiary (OLDANSWERS=1 plays
      // without them): strike a ghoul's reaching claw aside if the swing is ready,
      // and pull a door shut across a charge's line when one stands open beside you
      if (trick && !process.env.OLDANSWERS) {
        const mv = trick.windup.move, dx = Math.sign(trick.x - p.x), dy = Math.sign(trick.y - p.y);
        const toward = Dungeon.DIRS.findIndex(([ax, ay]) => ax === dx && ay === dy);
        const adjacent = Math.abs(trick.x - p.x) + Math.abs(trick.y - p.y) === 1;
        // a blink hound at your back is met face on; raised quills and crossed blades are waited out;
        // a wyrm's fire is dodged by closing in under its jaws when one step does it
        if (mv === 'blink' && adjacent) {
          if (toward !== p.dir) { Game.input(toward === (p.dir + 1) % 4 ? 'right' : 'left'); rec.dodges = (rec.dodges || 0) + 1; }
          step(); continue;
        }
        if ((mv === 'bristle' || mv === 'parry') && adjacent) { step(); continue; }
        if ((mv === 'breath' || mv === 'thrust') && toward >= 0 && (dx === 0 || dy === 0) && Math.abs(trick.x - p.x) + Math.abs(trick.y - p.y) === 2) {
          const t = L.tiles[(p.y + dy) * L.w + p.x + dx];
          if ((t === T.FLOOR || t === T.DOOR_OPEN) && !L.monsters.some(o => o.x === p.x + dx && o.y === p.y + dy)) {
            Game.input(['forward', 'strafeR', 'back', 'strafeL'][(toward - p.dir + 4) % 4]); rec.dodges = (rec.dodges || 0) + 1; step(); continue;
          }
        }
        if (mv === 'paralyse' && adjacent && G.t >= p.nextAttack) {
          p.dir = toward; Game.input('attack'); rec.struckAside = (rec.struckAside || 0) + 1; step(); continue;
        }
        if (mv === 'charge' && toward >= 0 && (dx === 0 || dy === 0)) {
          const t = L.tiles[(p.y + dy) * L.w + p.x + dx];
          if (t === T.DOOR_OPEN && !(trick.x === p.x + dx && trick.y === p.y + dy) && !(L.items[`${p.x + dx},${p.y + dy}`] || []).length) {
            p.dir = toward; Game.input('use'); rec.shut = (rec.shut || 0) + 1; step(); continue;
          }
        }
      }
      if (trick) {
        const mv = trick.windup.move, sideways = mv === 'charge' || mv === 'web' || mv === 'breath' || mv === 'thrust' || mv === 'firepot' || mv === 'firearrow' || mv === 'chill' || mv === 'storm' || mv === 'stamp' || mv === 'aim';
        const d0 = Math.abs(trick.x - p.x) + Math.abs(trick.y - p.y);
        let best = null, score = -1;
        for (let k = 0; k < 4; k++) {
          const [dx, dy] = Dungeon.DIRS[k];
          const nx = p.x + dx, ny = p.y + dy;
          const t = L.tiles[ny * L.w + nx];
          if (t !== T.FLOOR && t !== T.DOOR_OPEN) continue;
          if (L.monsters.some(o => o.x === nx && o.y === ny) || (L.npcs || []).some(o => o.x === nx && o.y === ny)) continue;
          if (Game.fieldAt && Game.fieldAt(nx, ny) && Game.fieldAt(nx, ny).k === 'fire') continue;
          const dd = Math.abs(trick.x - nx) + Math.abs(trick.y - ny);
          const inLine = nx === trick.x || ny === trick.y;
          if (sideways ? inLine : dd <= d0) continue;
          if (dd > score) { score = dd; best = k; }
        }
        if (best !== null) {
          Game.input(['forward', 'strafeR', 'back', 'strafeL'][(best - p.dir + 4) % 4]);
          rec.dodges = (rec.dodges || 0) + 1;
          step();
          continue;
        }
      }
    }

    // --- a grey dwarf grown to twice its height is given room until it shrinks, as the bestiary
    // says: a step back from it whenever one is open, rather than trading blows half as hard again
    // (NOROOM=1 stands its ground, to measure what the step back is worth)
    if (!process.env.OLDANSWERS && !process.env.NOROOM) {
      const big = L.monsters.find(m => m.bigUntil > G.t && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) === 1);
      if (big) {
        const open = (x, y) => { const t = L.tiles[y * L.w + x]; return (t === T.FLOOR || t === T.DOOR_OPEN) && !L.monsters.some(o => o.x === x && o.y === y) && !(L.npcs || []).some(o => o.x === x && o.y === y) && !(Game.fieldAt && Game.fieldAt(x, y) && Game.fieldAt(x, y).k === 'fire'); };
        let best = -1, far = 1;
        for (let k = 0; k < 4; k++) {
          const [dx, dy] = Dungeon.DIRS[k], x = p.x + dx, y = p.y + dy;
          if (!open(x, y)) continue;
          const dd = Math.min(...L.monsters.filter(o => o.awake).map(o => Math.abs(o.x - x) + Math.abs(o.y - y)));
          if (dd > far) { far = dd; best = k; }
        }
        if (best >= 0) {
          Game.input(['forward', 'strafeR', 'back', 'strafeL'][(best - p.dir + 4) % 4]);
          rec.roomGiven = (rec.roomGiven || 0) + 1;
          step();
          continue;
        }
      }
    }

    // --- DODGE=1 steps straight back from every plain blow drawn back beside
    // it, as a twitchy human does; DODGE=2 has read the bestiary and steps
    // aside from a lunger or the lich's reach instead
    if (process.env.DODGE) {
      const foe = L.monsters.find(m => m.windup && m.windup.kind === 'melee' && !m.windup.move && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) === 1 && m.windup.until - G.t < 400);
      if (foe) {
        const mb = MONSTERS[foe.id], ax = p.x - foe.x, ay = p.y - foe.y;
        const open = (x, y) => { const t = L.tiles[y * L.w + x]; return (t === T.FLOOR || t === T.DOOR_OPEN) && !L.monsters.some(o => o.x === x && o.y === y) && !(L.npcs || []).some(o => o.x === x && o.y === y); };
        const aside = process.env.DODGE === '2' && (mb.lunge || mb.reach) ? [[ay, ax], [-ay, -ax]].map(([dx, dy]) => [p.x + dx, p.y + dy]).filter(([x, y]) => open(x, y)) : [];
        const to = aside[0] || (open(p.x + ax, p.y + ay) ? [p.x + ax, p.y + ay] : null);
        if (to) {
          const k = Dungeon.DIRS.findIndex(([dx, dy]) => dx === to[0] - p.x && dy === to[1] - p.y);
          Game.input(['forward', 'strafeR', 'back', 'strafeL'][(k - p.dir + 4) % 4]);
          rec.blowDodges = (rec.blowDodges || 0) + 1;
          step();
          continue;
        }
      }
    }

    // --- a Scroll of Lightning at two or more in a line ahead, or one standing in water (never
    // with the hero's own feet wet: the bolt runs back); a Scroll of Frost at what the cold bites,
    // at one in water, or at anything two or three squares off when the hero is hurt. NOSCROLLS=1 plays without.
    if (!process.env.NOSCROLLS && G.t >= p.nextAttack && !Game.shaped()) {
      const bolt = p.inv.find(i => i.t === 'scroll_lightning'), cone = p.inv.find(i => i.t === 'scroll_frost');
      if (bolt || cone) {
        let best = null;
        for (let k = 0; k < 4; k++) {
          const [dx, dy] = Dungeon.DIRS[k], line = [];
          for (let i = 1; i <= 3; i++) {
            const x = p.x + dx * i, y = p.y + dy * i, t = L.tiles[y * L.w + x];
            if (t !== T.FLOOR && t !== T.DOOR_OPEN) break;
            const m = L.monsters.find(mm => mm.x === x && mm.y === y && !mm.sunk && !mm.collapsed && shown(mm) && mm.awake);
            if (m) line.push({ m, i });
          }
          if (!line.length) continue;
          const wetOne = line.some(o => Game.wet(o.m.x, o.m.y)), cold = line.some(o => ['emberling', 'heartforged', 'wyrm', 'basilisk'].includes(o.m.id));
          const score = line.length * 2 + (wetOne ? 3 : 0) + (cold ? 2 : 0) + (hpFrac < 0.5 && line[0].i >= 2 ? 2 : 0);
          if (score >= 4 && (!best || score > best.score)) best = { k, score, wetOne, cold };
        }
        if (best) {
          const read = bolt && !Game.wet(p.x, p.y) && (best.wetOne || !best.cold) ? bolt : cone;
          if (read) { p.dir = best.k; const q0 = read.q || 1; Game.useItem(read); if (!p.inv.includes(read) || (read.q || 1) < q0) { rec.scrollsRead = (rec.scrollsRead || 0) + 1; step(); continue; } }
        }
      }
    }
    // --- lamp oil: throw a flask at something coming down a passage two or three
    // squares off, then set it alight (a Flame Strike, a fire-oiled shot, a
    // fireball scroll). The living shy from the flames, and it burns meanwhile.
    // NOFLASK=1 plays without.
    // (never on moss: its fire would spread back to the hero's own feet)
    if (!process.env.NOFLASK && G.t >= p.nextAttack && !Game.shaped() && L.twist !== 'overgrown') {
      const flask = p.inv.find(i => i.t === 'lamp_oil');
      const wepNow = Game.weapon();
      const fireShot = !!wepNow.range && ((p.coating && p.coating.t === 'fire' && p.coating.left > 0) || Game.hasPower('flame', 'weapon'));
      const strike = Game.knownSpells().find(sp => sp.id === 'flame_strike' && Game.spellAvailable(sp) && p.sp >= Game.spellCost(sp));
      const scroll = p.inv.find(i => ITEMS[i.t].kind === 'scroll' && ITEMS[i.t].effect === 'fire');
      const oiled = (x, y) => { const f = Game.fieldAt(x, y); return !!f && f.k === 'oil'; };
      let aim = null;
      for (let k = 0; k < 4 && !aim; k++) {
        const [dx, dy] = Dungeon.DIRS[k];
        for (let i = 1; i <= 3; i++) {
          const x = p.x + dx * i, y = p.y + dy * i, t = L.tiles[y * L.w + x];
          if (t !== T.FLOOR && t !== T.DOOR_OPEN) break;
          const m = L.monsters.find(mm => mm.x === x && mm.y === y && !mm.sunk && !mm.collapsed && shown(mm));
          if (m) { if (i >= 2 && m.awake && !MONSTERS[m.id].boss) aim = { k, i, m }; break; }
        }
      }
      if (aim) {
        const reachFire = (fireShot && wepNow.range >= aim.i) || (strike && strike.range >= aim.i) || (scroll && aim.i <= 3);
        if (reachFire && oiled(aim.m.x, aim.m.y)) {
          // it stands in the oil: light it (a fire-oiled shot is loosed below as any shot is)
          p.dir = aim.k;
          if (strike && strike.range >= aim.i && Game.castSpell(strike) !== false) { rec.flasksLit = (rec.flasksLit || 0) + 1; step(); continue; }
          if (!fireShot && scroll) { const q0 = scroll.q || 1; Game.useItem(scroll); if (!p.inv.includes(scroll) || (scroll.q || 1) < q0) { rec.flasksLit = (rec.flasksLit || 0) + 1; step(); continue; } }
          if (fireShot) rec.flasksLit = (rec.flasksLit || 0) + 1;
        } else if (reachFire && flask && hpFrac > 0.3) {
          p.dir = aim.k;
          const q0 = flask.q; Game.useItem(flask);
          if (!p.inv.includes(flask) || flask.q < q0) { rec.flasksThrown = (rec.flasksThrown || 0) + 1; step(); continue; }
        }
      }
    }

    // --- shoot down the corridor before anything closes the distance
    // standing in water, lightning at anything within two squares would run back into the hero (NOWADE=1 plays without knowing it)
    const wading = !process.env.NOWADE && (L.twist === 'flooded' || (L.dressing || []).some(q => q.k === 'puddle' && q.x === p.x && q.y === p.y));
    const shocksMe = (sp, dist) => wading && sp.element === 'lightning' && dist <= 2;
    // a caster who has seen a thing shrug off its first choice reaches for what
    // hurts it most: a Pyromancer turns to the cold against the Heartforged and
    // its embers, where the bot that burned them anyway lost a fifth more mages
    // at the bottom of a Long Delve (ELEMENTBLIND=1 burns them anyway)
    const avgDmg = sp => { const [n, s, b] = sp.dmg(p.level); return n * (s + 1) / 2 + b; };
    const taken = (m, sp) => { const t = ELEMENTS_TAKEN[m.id] || {}, el = sp.fire ? 'fire' : sp.element; return el && t[el] ? t[el] : 1; };
    const against = (m, first, pool) => {
      if (process.env.ELEMENTBLIND || !first || !first.dmg || taken(m, first) >= 1) return first;
      let best = first, bv = avgDmg(first) * taken(m, first);
      for (const o of pool) { const v = o.dmg ? avgDmg(o) * taken(m, o) : 0; if (v > bv) { best = o; bv = v; } }
      return best;
    };
    const bolts = process.env.NOBOLT || G.t < p.nextAttack || Game.shaped() ? [] : Game.knownSpells().filter(sp => Game.spellAvailable(sp) && p.sp >= Game.spellCost(sp) && sp.kind === 'bolt');
    if (bolts.length) {
      let shot = null;
      for (let k = 0; k < 4 && !shot; k++) {
        const [dx, dy] = Dungeon.DIRS[k];
        for (let i = 1; i <= 5; i++) {
          const x = p.x + dx * i, y = p.y + dy * i;
          const t = L.tiles[y * L.w + x];
          if (t !== T.FLOOR && t !== T.DOOR_OPEN) break;
          const m = L.monsters.find(mm => mm.x === x && mm.y === y);
          // a mimic still shut is a barrel in the way, not a mark: the game will not aim a spell at
          // it, and a bot that kept trying stood casting at it until the run ran out of time
          if (m && !shown(m)) break;
          if (m) {
            // a Pyromancer burns what is beside them rather than spend on the cold
            const reach = b => (Game.spellRange ? Game.spellRange(b) : b.range);
            const fit = bolts.filter(b => reach(b) >= i && !shocksMe(b, i));
            const sp = against(m, (i <= reach({ id: 'burning_hands', range: 1 }) && p.path === 'pyromancer' && bolts.find(b => b.id === 'burning_hands')) || fit[fit.length - 1], fit);
            if (sp && (i > 1 || p.sp > Game.spellCost(sp) * 2)) shot = { dir: k, sp };
            break;
          }
        }
      }
      if (shot) { p.dir = shot.dir; Game.castSpell(shot.sp); step(); continue; }
    }

    // --- loose a missile if the weapon in hand reaches
    const wep = Game.weapon();
    if (wep.range) {
      let shot = null;
      for (let k = 0; k < 4 && !shot; k++) {
        const [dx, dy] = Dungeon.DIRS[k];
        for (let i = 2; i <= wep.range; i++) {
          const x = p.x + dx * i, y = p.y + dy * i;
          const t = L.tiles[y * L.w + x];
          if (t !== T.FLOOR && t !== T.DOOR_OPEN) break;
          if (L.monsters.some(mm => mm.x === x && mm.y === y && shown(mm))) { shot = k; break; }
        }
      }
      if (shot !== null) { p.dir = shot; Game.input('attack'); step(); continue; }
    }

    // --- break off when badly hurt and out of remedies
    if (hpFrac < 0.32 && !heal) {
      const threats = L.monsters.filter(m => m.awake && Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 7);
      if (threats.length && !threats.some(m => Math.abs(m.x - p.x) + Math.abs(m.y - p.y) <= 1)) {
        const away = field(L, threats[0].x, threats[0].y, true);
        const here = away[p.y * L.w + p.x];
        let best = null, bd = here;
        for (let k = 0; k < 4; k++) {
          const [dx, dy] = Dungeon.DIRS[k];
          const nx = p.x + dx, ny = p.y + dy;
          if (nx < 0 || ny < 0 || nx >= L.w || ny >= L.h) continue;
          const dd = away[ny * L.w + nx];
          if (dd > bd) { bd = dd; best = k; }
        }
        if (best !== null) { p.dir = best; Game.input('forward'); rec.retreats = (rec.retreats || 0) + 1; step(); continue; }
      }
    }

    // --- the Warlord on his throne: a bolt flies over his shield-bearers, so a caster turns and throws one
    {
      const wl = L.monsters.find(m => m.id === 'warlord' && m.throne);
      const bolt = wl && G.t >= p.nextAttack && Game.knownSpells().filter(s => s.kind === 'bolt' && Game.spellAvailable(s) && p.sp >= Game.spellCost(s)).pop();
      if (bolt && (wl.x === p.x || wl.y === p.y) && Math.abs(wl.x - p.x) + Math.abs(wl.y - p.y) <= (bolt.range || 5)) {
        const dir = Dungeon.DIRS.findIndex(([dx, dy]) => dx === Math.sign(wl.x - p.x) && dy === Math.sign(wl.y - p.y));
        if (dir >= 0) { p.dir = dir; if (!Game.spellWasteReason(bolt)) { Game.castSpell(bolt); rec.overShields = (rec.overShields || 0) + 1; step(); continue; } }
      }
    }
    // --- fight what is adjacent, in front if possible; a lich wrapped in
    // shadow cannot be hurt, so its guards come first, as the game says
    const near = [];
    for (let k = 0; k < 4; k++) {
      const [dx, dy] = Dungeon.DIRS[k];
      const m = L.monsters.find(mm => mm.x === p.x + dx && mm.y === p.y + dy && shown(mm));
      if (m) near.push({ m, dir: k });
    }
    const adj = near.find(a => !(a.m.wardUntil > G.t)) || near[0] || null;
    // a puffcap beside it, with no fire on the blade and not yet poisoned: a
    // spell looses no spores, and one with a bow steps back (a puffcap is slow) to shoot
    if (adj && adj.m.id === 'puffcap' && puffNear && !p.poison && !(p.coating && p.coating.t === 'fire') && !Game.hasPower('flame', 'weapon')) {
      const bolt = Game.shaped() ? null : Game.knownSpells().filter(s => s.kind === 'bolt' && Game.spellAvailable(s) && p.sp >= Game.spellCost(s)).pop();
      if (bolt && G.t >= p.nextAttack) { p.dir = adj.dir; Game.castSpell(bolt); rec.puffAnswers = (rec.puffAnswers || 0) + 1; step(); continue; }
      if (Game.weapon().range) {
        const bx = p.x - Dungeon.DIRS[adj.dir][0], by = p.y - Dungeon.DIRS[adj.dir][1], t = L.tiles[by * L.w + bx];
        if ((t === T.FLOOR || t === T.DOOR_OPEN) && !L.monsters.some(o => o.x === bx && o.y === by) && !(L.npcs || []).some(o => o.x === bx && o.y === by)) {
          p.dir = adj.dir; Game.input('back'); rec.puffAnswers = (rec.puffAnswers || 0) + 1; step(); continue;
        }
      }
    }
    if (adj) {
      if (p.dir !== adj.dir) { p.dir = adj.dir; }
      // cast when it is clearly better than swinging
      const spells = process.env.NOBOLT || Game.shaped() ? [] : Game.knownSpells().filter(s => Game.spellAvailable(s) && p.sp >= Game.spellCost(s) && s.kind === 'bolt' && !shocksMe(s, 1));
      // points kept back for the next fight are no use against the last one
      // a Pyromancer reaches for fire first, at the same moments
      const pick = against(adj.m, (p.path === 'pyromancer' && spells.find(s => s.id === 'burning_hands')) || spells[spells.length - 1], spells);
      if (spells.length && (p.sp > p.maxSp * 0.4 || MONSTERS[adj.m.id].boss)) Game.castSpell(pick);
      else Game.input('attack');
      step();
      continue;
    }

    // --- rest when safe and hurt (on the ladder's third rung a rest wakes what can hear it, so as a
    // player would: only once little is left on it, or standing on the stairs with the way down
    // at hand, since what is roused is left behind; a hero near death rests anyway)
    // (under a Gallows Ring rest mends no life: only spell points send it to rest then)
    if (((hpFrac < 0.75 && !Game.hasPower('gallows')) || (p.maxSp && p.sp < p.maxSp * 0.4)) && p.food > 10) {
      const roused = Game.rung() >= 3;
      const byStair = !!L.stairsDown && Math.abs(p.x - L.stairsDown.x) + Math.abs(p.y - L.stairsDown.y) === 1;
      const left = roused ? L.monsters.filter(m => !m.collapsed && !m.sunk && !m.disguised).length : 0;
      if (!roused || byStair || left <= 2 || hpFrac < 0.3) {
        if (Game.rest()) { rec.rests++; if (roused && byStair) rec.restsByStair = (rec.restsByStair || 0) + 1; step(); continue; }
      } else if (L.stairsDown && hpFrac < 0.6) {
        // hurt on a floor that would wake: make for the stairs and rest beside them
        stepToward(L.stairsDown.x, L.stairsDown.y); rec.stairRuns = (rec.stairRuns || 0) + 1; step(); continue;
      }
    }

    // --- answer an encounter the way a thoughtful player would: read what
    // success and failure would each do, weigh them by the odds and by how
    // much this hero can afford to lose, and walk away unless it is worth it.
    // (The first version took any check better than even and ignored the
    // stakes, which made fragile heroes take gambles a person would refuse.)
    // at the divided stair: ROUTE=crypts|warrens, or each seed its own way
    if (Game.forkPending()) {
      const road = process.env.ROUTE || (seed.split('').reduce((a, c) => a + c.charCodeAt(0), 0) % 2 ? 'crypts' : 'warrens');
      Game.chooseRoute(road); rec.route = road;
      continue;
    }
    if (Game.currentEncounter()) {
      const cur = Game.currentEncounter();
      if (!cur.result) {
        const frail = 30 / Math.max(10, p.maxHp);            // how much a blow matters to this hero
        const worth = effects => effects.reduce((v, e) => {
          if (e.map) v += 2;
          if (e.xp) v += e.xp / 25;
          if (e.goldPerDepth) v += e.goldPerDepth / 12;
          if (e.goldBack) v += e.goldBack / 12;
          if (e.hone) v += p.eq[e.hone] && (p.eq[e.hone].e || 0) < 4 ? 3 : 0;
          if (e.hurt) v -= (e.hurt[0] * (e.hurt[1] + 1) / 2 + e.hurt[2]) / Math.max(1, p.hp) * 12;
          if (e.hurtFrac) v -= e.hurtFrac * p.maxHp / Math.max(1, p.hp) * 12;
          if (e.heal) v += (e.heal === 'full' ? (p.maxHp - p.hp) : e.heal) / p.maxHp * 5;
          if (e.maxHp) v += e.maxHp > 0 ? e.maxHp * 0.6 : e.maxHp * 0.9;
          if (e.food) v += e.food / 30;
          if (e.loot != null) v += 2 + e.loot;
          if (e.item) v += 1;
          if (e.buff) v += 2;
          if (e.poison) v -= 2 * frail;
          if (e.cure) v += p.poison ? 2 : 0;
          if (e.wake) v -= p.cls === 'thief' ? 5 : 3;
          if (e.identifyAll) v += 2;
          // (robbing the Lampfolk makes every trader of theirs below a sixth dearer)
          if (e.thread) v += e.thread === 'bargain' ? 3 : e.thread === 'robbed' ? -1.5 : 0.5;
          if (e.companion && !(G.companion && !G.companion.fallen)) v += 5;
          if (e.ambush) v -= (e.ambush.id === 'wraith' ? 5 : 3) * e.ambush.n * frail;
          return v;
        }, 0);
        let best = null, bestValue = 0;
        cur.def.choices.forEach((ch, i) => {
          const o = Game.encounterOptions()[i];
          if (o.blocked) return;
          let v = ch.check ? o.chance * worth(ch.pass.effects) + (1 - o.chance) * worth(ch.fail.effects) : worth(ch.outcome.effects);
          // gold has nothing left to buy at the last floor's lamp: only what it gives counts
          if (ch.cost && ch.cost.goldPerDepth && !cur.def.final) v -= ch.cost.goldPerDepth / 12;
          if (ch.cost && ch.cost.hurtFrac) v -= ch.cost.hurtFrac * 12;
          if (ch.cost && ch.cost.food) v -= ch.cost.food / 30;   // as a food effect is valued
          if (v > bestValue) { bestValue = v; best = o; }
        });
        // nothing worth the risk: take the way out, which is always last
        // (ENCLEAVE=1 always walks away: the detour without the rewards)
        if (!best || process.env.ENCLEAVE) best = Game.encounterOptions()[cur.def.choices.length - 1];
        if (process.env.MYTHIC === 'trial') {
          const trial = cur.def.choices.findIndex(ch => ch.outcome && ch.outcome.effects.some(e => e.mythic));
          if (trial >= 0 && !Game.encounterOptions()[trial].blocked) best = Game.encounterOptions()[trial];
        }
        const r = Game.chooseEncounter(best.i);
        if (r && r.preparing === true) continue;
        rec.encounters = (rec.encounters || 0) + 1;
        if (cur.def.final) rec.lamp = cur.def.choices[best.i] && cur.def.choices[best.i].cost ? best.label : 'nothing bought';
        // tally what the encounter actually handed over, for ENCLOG=1
        rec.encGot = rec.encGot || {};
        rec.encChose = rec.encChose || {};
        rec.encChose[`${cur.def.title} / ${best.label}`] = (rec.encChose[`${cur.def.title} / ${best.label}`] || 0) + 1;
        for (const l of (r ? r.lines : [])) {
          let m;
          if ((m = l.match(/^\+(\d+) experience/))) rec.encGot.xp = (rec.encGot.xp || 0) + Number(m[1]);
          else if ((m = l.match(/^([+−])(\d+) maximum hit points/))) rec.encGot.maxHp = (rec.encGot.maxHp || 0) + (m[1] === '+' ? 1 : -1) * Number(m[2]);
          else if ((m = l.match(/^\+(\d+) gold/))) rec.encGot.gold = (rec.encGot.gold || 0) + Number(m[1]);
          else if ((m = l.match(/^−(\d+) hit points/))) rec.encGot.hurt = (rec.encGot.hurt || 0) + Number(m[1]);
          else if (/^Blessed/.test(l)) rec.encGot.blessed = (rec.encGot.blessed || 0) + 1;
          else if (/^Found/.test(l)) rec.encGot.found = (rec.encGot.found || 0) + 1;
          else if (/attack/.test(l)) rec.encGot.ambush = (rec.encGot.ambush || 0) + 1;
          else if (/awake/.test(l)) rec.encGot.woke = (rec.encGot.woke || 0) + 1;
          else if (/Fully healed/.test(l)) rec.encGot.healed = (rec.encGot.healed || 0) + 1;
        }
        if (r && r.check) rec[r.check.pass ? 'encPass' : 'encFail'] = (rec[r.check.pass ? 'encPass' : 'encFail'] || 0) + 1;
      }
      Game.closeEncounter();
      step();
      continue;
    }

    // --- visit the trader while we still have coin and room to carry
    // (encounter props stand in the same list, so find the trader by kind)
    const npc = (L.npcs || []).find(n => n.kind !== 'encounter');
    // give up after a while: the trader may sit behind a door we have no key for
    // every trader once, as a person would (SHOPONCE=1: only the first, the old way)
    const shopKey = process.env.SHOPONCE ? 'any' : G.depth;
    rec.shopped = rec.shopped || {}; rec.shopTries = rec.shopTries || {};
    if (npc && !rec.shopped[shopKey] && p.gold >= 50 && (rec.shopTries[shopKey] = (rec.shopTries[shopKey] || 0) + 1) < 140) {
      const beside = Math.abs(npc.x - p.x) + Math.abs(npc.y - p.y) === 1;
      if (Game.currentShop()) {
        // stock up on what keeps us alive, cheapest first
        const s = Game.currentShop();
        // free of a curse before anything else
        const lift = Game.shopServices().find(v => v.id === 'uncurse');
        if (lift && !lift.why && p.gold >= lift.price && Game.buyService('uncurse')) rec.uncursed = (rec.uncursed || 0) + 1;
        // a relic this hero can use comes first: it is what the gold is for
        const relic = s.stock.find(i => i.u && !Game.canEquip(i) && p.gold >= Game.buyPrice(s, i));
        if (relic && Game.buy(relic)) rec.relicsBought = (rec.relicsBought || 0) + 1;
        // and a ring or an amulet, if there is room to wear it and gold to
        // spare: bought with the potion money it cost the bot more lives than
        // it saved (found-only matched no rings at all; buying lost 3-4 points)
        const jewel = !process.env.NOJEWELS && !process.env.NOJEWELBUY && s.stock.find(i => ['ring', 'amulet'].includes(ITEMS[i.t].kind)
          && (ITEMS[i.t].kind === 'ring' ? !p.eq.ring || !p.eq.ring2 : !p.eq.amulet) && p.gold >= Game.buyPrice(s, i) * 2 + 150);
        if (jewel && Game.buy(jewel)) rec.jewelsBought = (rec.jewelsBought || 0) + 1;
        const want = s.stock
          .filter(i => ['potion_heal', 'potion_xheal', 'ration', 'meat', 'potion_cure'].includes(i.t))
          .sort((a, b) => Game.buyPrice(s, a) - Game.buyPrice(s, b));
        let bought = 0;
        for (const i of want) {
          while (i.q > 0 && p.gold >= Game.buyPrice(s, i) * 2 && p.inv.length < 18 && Game.buy(i)) { bought++; if (i.t === 'potion_heal' || i.t === 'potion_xheal') rec.draughtsBought = (rec.draughtsBought || 0) + 1; }
        }
        rec.bought = (rec.bought || 0) + bought;
        // a trader's job costs nothing: take it (NOJOBS=1 to leave them)
        if (!process.env.NOJOBS && Game.shopServices().some(v => v.id === 'bounty' && !v.why) && Game.buyService('bounty')) rec.jobs = (rec.jobs || 0) + 1;
        // a charm for a companion that wears none, with gold to spare
        // (a sellsword's whetstone first, even over what it wears; nobody else's)
        if (!process.env.NOCHARM && Game.companion() && !Game.companion().fallen && !p.inv.some(i => ITEMS[i.t].kind === 'charm')) {
          const c = Game.companion(), hired = c.kind === 'sellsword', can = x => x.q > 0 && p.gold >= Game.buyPrice(s, x) + 150;
          const ch = hired && c.charm !== 'charm_whetstone' ? s.stock.find(x => x.t === 'charm_whetstone' && can(x)) : null;
          if (ch) Game.buy(ch);
          else if (!c.charm) { const any = s.stock.find(x => ITEMS[x.t].kind === 'charm' && x.t !== 'charm_whetstone' && can(x)); if (any) Game.buy(any); }
        }
        // an oil or two with gold to spare (silver in the Crypts, where the dead are), unless NOOIL=1
        if (!process.env.NOOIL) {
          const oils = () => p.inv.filter(i => ITEMS[i.t].kind === 'oil').reduce((a, i) => a + (i.q || 1), 0);
          const pref = G.route === 'crypts' ? ['oil_silver', 'oil_fire', 'oil_venom'] : ['oil_fire', 'oil_venom', 'oil_silver'];
          for (const t of pref) {
            const i = s.stock.find(x => x.t === t && x.q > 0);
            while (i && i.q > 0 && oils() < 2 && p.gold >= Game.buyPrice(s, i) * 2 + 100 && p.inv.length < 18 && Game.buy(i)) rec.oilsBought = (rec.oilsBought || 0) + 1;
          }
        }
        // a flask or two of lamp oil for a hero who can set it alight from off (a cleric's
        // Flame Strike, a bow or sling with fire oil to hand), unless NOFLASK=1
        if (!process.env.NOFLASK && (p.cls === 'cleric' || (Game.weapon().range && ((p.coating && p.coating.t === 'fire') || p.inv.some(i => ITEMS[i.t].coat === 'fire'))))) {
          const lo = s.stock.find(x => x.t === 'lamp_oil' && x.q > 0);
          const have = () => p.inv.filter(i => i.t === 'lamp_oil').reduce((a, i) => a + (i.q || 1), 0);
          while (lo && lo.q > 0 && have() < 2 && p.gold >= Game.buyPrice(s, lo) * 2 + 100 && p.inv.length < 18 && Game.buy(lo)) rec.flasksBought = (rec.flasksBought || 0) + 1;
        }
        // then the forge, with what is left: better steel is what the rest of the gold is for
        if (!process.env.NOFORGE) {
          const svc = id => Game.shopServices().find(v => v.id === id);
          const ap = svc('appraise');
          if (ap && !ap.why && p.gold >= ap.price + 60) Game.buyService('appraise');
          // a safe night when hurt, then the forge, then a rune with what is left
          const lodge = svc('lodge');
          if (lodge && !lodge.why && p.hp < p.maxHp * 0.7 && p.gold >= lodge.price + 20 && Game.buyService('lodge')) rec.lodged = (rec.lodged || 0) + 1;
          for (let n = 0; n < 8; n++) {
            const next = ['hone', 'reinforce', 'rune_weapon', 'rune_armor', 'make_weapon', 'make_armor', 'study', 'tonic'].map(svc).filter(v => v && !v.why && p.gold >= v.price + 20).sort((a, b) => a.price - b.price)[0];
            if (!next || !Game.buyService(next.id)) break;
            if (next.id.startsWith('rune')) rec.runes = (rec.runes || 0) + 1; else if (next.id.startsWith('make')) rec.made = (rec.made || 0) + 1; else if (next.id === 'tonic') rec.tonics = (rec.tonics || 0) + 1; else rec.forged = (rec.forged || 0) + 1;
          }
        }
        rec.shopped[shopKey] = true;
        Game.closeShop();
        step();
        continue;
      }
      if (beside) {
        p.dir = Dungeon.DIRS.findIndex(([dx, dy]) => p.x + dx === npc.x && p.y + dy === npc.y);
        Game.input('forward');
        step();
        continue;
      }
      stepToward(npc.x, npc.y);
      step();
      continue;
    }
    if (npc && rec.shopTries[shopKey] >= 140) rec.shopped[shopKey] = true;   // stop trying, get on with it

    // --- walk up to an encounter on this floor (ENC=0 ignores them, to compare)
    const enc = ENC && (L.npcs || []).find(n => n.kind === 'encounter');
    if (enc) {
      const k = `${G.depth}:${enc.x},${enc.y}`;
      rec.encTries = rec.encTries || {};
      rec.encTries[k] = (rec.encTries[k] || 0) + 1;
      if (rec.encTries[k] < 140) {
        if (Math.abs(enc.x - p.x) + Math.abs(enc.y - p.y) === 1) {
          p.dir = Dungeon.DIRS.findIndex(([dx, dy]) => p.x + dx === enc.x && p.y + dy === enc.y);
          Game.input('forward');
        } else stepToward(enc.x, enc.y);
        step();
        continue;
      }
    }

    // --- sweep the floor first when playing thoroughly
    if (EXPLORE && L.stairsDown) {
      const fl = (rec.floors = rec.floors || {})[G.depth] = rec.floors[G.depth] || { seen: new Uint8Array(L.w * L.h), done: new Set(), ticks: 0, open: 0 };
      const R = 3;
      for (let dy = -R; dy <= R; dy++) for (let dx = -R; dx <= R; dx++) {
        const x = p.x + dx, y = p.y + dy;
        if (x >= 0 && y >= 0 && x < L.w && y < L.h) fl.seen[y * L.w + x] = 1;
      }
      fl.done.add(`${p.x},${p.y}`);
      // a door we hold the key for is a door, not a wall
      const colors = new Set(p.inv.filter(i => i.t === 'key').map(i => i.color));
      const reach = field(L, p.x, p.y, false, colors);
      if (!fl.open) for (let i = 0; i < reach.length; i++) if (reach[i] >= 0) fl.open++;
      let seen = 0;
      for (let i = 0; i < reach.length; i++) if (reach[i] >= 0 && fl.seen[i]) seen++;
      let goal = -1, gd = Infinity;
      for (const k in L.items) {
        if (!L.items[k].length || fl.done.has(k)) continue;
        const [x, y] = k.split(',').map(Number), d = reach[y * L.w + x];
        if (d > 0 && d < gd) { gd = d; goal = y * L.w + x; }
      }
      // a vault's chest is a find as much as what lies loose: walking into it kicks it open
      for (const q of L.dressing || []) {
        if (q.k !== 'chest') continue;
        const d = reach[q.y * L.w + q.x];
        if (d > 0 && d < gd) { gd = d; goal = q.y * L.w + q.x; }
      }
      if (goal < 0 && seen < fl.open * EXPLORE) {
        for (let i = 0; i < reach.length; i++) if (reach[i] > 0 && !fl.seen[i] && reach[i] < gd) { gd = reach[i]; goal = i; }
      }
      // a budget, so a floor that will not give up its last corner cannot hold the run
      if (goal >= 0 && ++fl.ticks < 4000) {
        stepToward(goal % L.w, (goal / L.w) | 0, colors);
        step();
        continue;
      }
    }

    // The explicit trial policy collects only its earned Mythic. Ordinary loot
    // still follows the existing navigation and pickup policy.
    if (process.env.MYTHIC === 'trial' && L.mythicTrial === 'won') {
      const prize = Object.entries(L.items).find(([,pile]) => pile.some(it => it.u && RELICS[it.u].mythic));
      if (prize) {
        const [x,y] = prize[0].split(',').map(Number);
        if (p.x === x && p.y === y) {
          const it = prize[1].find(it => it.u && RELICS[it.u].mythic);
          if (p.inv.length < Game.INV_MAX) { Game.takeItem(it); step(); continue; }
        } else { stepToward(x,y); step(); continue; }
      }
    }

    // --- otherwise head for the down stairs, picking up what we pass
    const target = L.stairsDown;
    if (!target) {
      // final level: the Heart will not come loose while the lich stands, so
      // bring it down first, then take the Heart and the run is won
      const lich = L.monsters.find(m => MONSTERS[m.id].boss);
      let goal = lich ? [lich.x, lich.y] : null;
      for (const k in L.items) if (!goal && L.items[k].some(i => i.t === 'artifact')) goal = k.split(',').map(Number);
      if (goal && !lich && p.x === goal[0] && p.y === goal[1]) Game.input('use');
      else if (goal) stepToward(goal[0], goal[1]);
    } else {
      stepToward(target.x, target.y);
    }
    step();

    function stepToward(tx, ty, colors) {
      const L2 = Game.level();
      const dist = colors ? field(L2, tx, ty, false, colors) : field(L2, tx, ty, true);
      const here = dist[p.y * L2.w + p.x];
      let best = null, bd = here < 0 ? Infinity : here;
      for (let k = 0; k < 4; k++) {
        const [dx, dy] = Dungeon.DIRS[k];
        const nx = p.x + dx, ny = p.y + dy;
        if (nx < 0 || ny < 0 || nx >= L2.w || ny >= L2.h) continue;
        const t = L2.tiles[ny * L2.w + nx];
        if (t === T.STAIRS_DOWN && nx === tx && ny === ty) { best = k; bd = -1; break; }
        if (t === T.STAIRS_UP && nx === tx && ny === ty) { best = k; bd = -1; break; }
        const dd = dist[ny * L2.w + nx];
        if (dd >= 0 && dd < bd) { bd = dd; best = k; }
      }
      if (best === null) { p.dir = (p.dir + 1) % 4; return; }
      p.dir = best;
      // something battering at the door ahead: a player hears it and does not
      // open the door into it, but waits facing it for it to come through
      const [bx, by] = Dungeon.DIRS[best], doorX = p.x + bx, doorY = p.y + by;
      if (!process.env.OLDANSWERS && L2.tiles[doorY * L2.w + doorX] === T.DOOR && (L2.doorBlows || {})[`${doorX},${doorY}`]
        && L2.monsters.some(m => m.awake && Math.abs(m.x - doorX) + Math.abs(m.y - doorY) === 1)) { rec.waitedAtDoor = (rec.waitedAtDoor || 0) + 1; return; }
      // a kobold's snare in the way, seen where it glints: sprung from before it, as a player would
      if ((L2.snares || {})[`${doorX},${doorY}`]) { Game.input('use'); rec.snaresSprung = (rec.snaresSprung || 0) + 1; return; }
      Game.input('forward');
    }
  }
  const fin = snap();
  rec.adjAtEnd = fin.adj; rec.nearAtEnd = fin.near; rec.awakeAtEnd = fin.awake; rec.totalAtEnd = fin.total;
  if (process.env.DUMP) rec.tail = G.log.slice(-parseInt(process.env.DUMP, 10)).map(l => l.m);
  rec.killerLog = G.log.slice(-6).map(l => l.m).filter(m => /hits you|shoots|poison|starv|trap|dart|needle|pit/i.test(m)).slice(-3);
  rec.goldSpent = rec.goldSpent || 0;
  rec.depth = G.depth;
  rec.deepest = p.deepest;
  // the hound, if one followed: whether it lasted, and what it killed
  rec.jobsPaid = (G.stats && G.stats.bounties) || 0;
  // where the rest of the jobs went: left undone on their floor, or done and never paid (no trader met after)
  rec.jobsLost = (G.stats && G.stats.bountiesLost) || 0;
  rec.jobDoneUnpaid = G.bounty && G.bounty.done ? 1 : 0;
  rec.jobOpen = G.bounty && !G.bounty.done ? 1 : 0;
  if (G.companion) { rec.hound = 1; rec.houndFell = G.companion.fallen ? 1 : 0; rec.houndKills = G.companion.kills || 0; }
  rec.kills = p.kills;
  rec.goldFound = p.gold;
  rec.died = G.status === 'dead';
  if (rec.died && !rec.cause) rec.cause = (G.lastAttacker && G.lastAttacker.name) || (p.food <= 0 ? 'starvation' : 'poison or a trap');
  rec.won = G.status === 'won';
  rec.level = p.level;
  // past the top level (it comes at XP_TABLE[MAX_LEVEL - 1]; the table's last entry is never reached)
  rec.capped = p.level >= MAX_LEVEL; rec.pastTop = p.xp - XP_TABLE[MAX_LEVEL - 1]; rec.renown = p.renown || 0;
  rec.timedOut = G.status === 'playing';
  // STUCKAT=1 prints where a run that ran out of time was standing, and what was left near it
  if (rec.timedOut && process.env.STUCKAT) {
    const L = Game.level();
    console.error(trace.join('\n'));
    console.error(`STUCK ${seed} floor ${G.depth} (theme ${L.theme}) at ${p.x},${p.y} hp ${p.hp}/${p.maxHp} awake ${L.monsters.filter(m => m.awake).map(m => `${m.id}@${Math.abs(m.x - p.x) + Math.abs(m.y - p.y)}`).join(' ')} held ${p.held > G.t ? p.heldBy : '-'} webbed ${p.webbed > G.t}`);
  }
  rec.dual = !!p.eq.offhand;
  // the named champions this run held, and which of them fell (NAMED=1 prints it)
  rec.namedHeld = Object.values(Dungeon.namedPlan(seed, opts.levels));
  rec.namedSlain = Object.keys(Game.runStats().kills).filter(id => MONSTERS[id] && MONSTERS[id].named);
  // with SHADE=n: whether the shade's floor was reached, it was laid to rest, or it killed the hero
  if (process.env.SHADE) {
    const at = Object.keys(G.levels).map(Number).find(d => G.levels[d].bones);
    rec.shadeMet = !!at && p.deepest >= at;
    rec.shadeRested = !!G.rested;
    rec.shadeKilled = rec.died && /^the Shade of/.test(rec.cause || '');
  }
  // a champion is remembered as "Grisk, the Goblin King", not by its kind's name alone
  rec.namedKiller = rec.died ? rec.namedHeld.find(id => rec.cause === MONSTERS[id].name || rec.cause.endsWith(', the ' + MONSTERS[id].name)) || '' : '';
  if (process.env.RELICLOG) {
    // why a relic was left behind: out of reach without a key, or a full pack
    rec.relicLeft = rec.relicLeft || { reach: 0, locked: 0, full: p.inv.length >= Game.INV_MAX ? 1 : 0 };
    for (const dd in G.levels) {
      const L = G.levels[dd];
      for (const k in L.items) if (L.items[k].some(i => i.u)) {
        const [x, y] = k.split(',').map(Number);
        rec.relicLeft[field(L, L.start.x, L.start.y, false)[y * L.w + x] >= 0 ? 'reach' : 'locked']++;
      }
    }
  }
  rec.potsAtEnd = p.inv.filter(i => i.t === 'potion_heal' || i.t === 'potion_xheal').reduce((a, i) => a + (i.q || 1), 0);
  rec.cursedAtEnd = Object.values(p.eq).some(i => i && i.curse) ? 1 : 0;
  rec.relics = [...p.inv, ...Object.values(p.eq)].filter(i => i && i.u).length;
  rec.relicsWorn = Object.values(p.eq).filter(i => i && i.u).length;
  // a legend for the hero's path: found at all, and worn at the end
  rec.mythicTrial = Object.values(G.levels).some(l => l.mythicTrial) ? 1 : 0;
  rec.mythicWon = Object.values(G.levels).some(l => l.mythicTrial === 'won') ? 1 : 0;
  rec.mythicWorn = Object.values(p.eq).some(i => i && i.u && RELICS[i.u].mythic) ? 1 : 0;
  rec.mythicTicks = G.stats && G.stats.mythicTicks || 0;
  rec.legend = ((G.relics && G.relics.found) || []).some(id => RELICS[id] && RELICS[id].legend) ? 1 : 0;
  // the combinations the run made (combos.js), for how often a win had one to name
  rec.combos = Object.keys(G.combos || {}).length;
  for (const id of Object.keys(G.combos || {})) comboSeen[id] = (comboSeen[id] || 0) + 1;
  rec.legendWorn = Object.values(p.eq).some(i => i && i.u && RELICS[i.u] && RELICS[i.u].legend) ? 1 : 0;
  rec.casts = { ...((G.stats && G.stats.spells) || {}) };
  rec.gear = `${p.eq.weapon ? p.eq.weapon.t : 'fists'}${p.eq.shield ? '+' + p.eq.shield.t : ''}${p.eq.armor ? ' in ' + p.eq.armor.t : ''}`;      // did this bot actually end up fighting two-handed
  return rec;
}

// MONSTERS=many (or few) measures a density other than the default
/** How many runs made each combination, over the whole bench (COMBOS=1 prints them). */
const comboSeen = {};
const opts = { ...(process.env.PUZZLES ? { puzzles: true } : {}), levels: parseInt(process.env.LEVELS || '8', 10), size: process.env.SIZE || 'medium', monsters: process.env.MONSTERS || 'normal', treasure: 'normal', lockedDoors: true, traps: true, permadeath: false, difficulty: (process.env.DIFF || 'normal').replace(/\+\d+$/, '') };
// DIFF=hard+3: a rung of the ladder past Hard
const rungAsked = Number(((process.env.DIFF || '').match(/^hard\+(\d+)$/) || [])[1]) || 0;
if (rungAsked) opts.rung = rungAsked;
// A fixed seed set so results are comparable between tuning passes. The dice are
// seeded per run too, so the same command twice gives the same answer.
// SEEDN / SEEDPFX pick a larger or different seed set (defaults: the 20 bench seeds)
const SEEDS = Array.from({ length: parseInt(process.env.SEEDN || '20', 10) }, (_, i) => (process.env.SEEDPFX || 'bench') + i);
const TRIALS = parseInt(process.argv[3] || '2', 10);
const classes = process.argv[2] ? [process.argv[2]] : ['fighter', 'cleric', 'mage', 'thief', 'ranger', 'druid'];
async function main() {
const results = {};
for (const cls of classes) {
  const rows = [];
  for (const seed of SEEDS) {
    // SEEDONLY=alt18 plays one seed of the set, with the background it has in the whole set
    if (process.env.SEEDONLY && seed !== process.env.SEEDONLY) continue;
    for (let t = 0; t < TRIALS; t++) {
      const ctx = await loadGame();
      // rotate backgrounds so the benchmark is not one perk repeated 60 times
      const bg = BACKGROUND_ROTATION[(SEEDS.indexOf(seed) * TRIALS + t) % BACKGROUND_ROTATION.length];
      try { rows.push(run(ctx, cls, seed, opts, bg, SEEDS.indexOf(seed) * TRIALS + t)); }
      catch (e) { rows.push({ cls, died: true, cause: 'ERROR ' + e.message, deepest: 0, level: 0 }); }
    }
  }
  results[cls] = rows;
}

let totalWin = 0, totalRuns = 0, totalDeep = 0;
for (const cls in results) {
  const rows = results[cls];
  const won = rows.filter(r => r.won).length;
  const stuck = rows.filter(r => r.timedOut).length;
  const errs = rows.filter(r => (r.cause || '').startsWith('ERROR'));
  const avg = k => rows.reduce((a, r) => a + (r[k] || 0), 0) / rows.length;
  totalWin += won; totalRuns += rows.length; totalDeep += avg('deepest') * rows.length;
  console.log(`${cls.padEnd(8)} win ${(won / rows.length * 100).toFixed(0).padStart(3)}%  avgDeepest ${avg('deepest').toFixed(2)}  avgLevel ${avg('level').toFixed(1)}  kills ${avg('kills').toFixed(0)}  rests ${avg('rests').toFixed(1)}  potions ${avg('potionsDrunk').toFixed(1)}  boons ${avg('boons').toFixed(1)}  bought ${avg('bought').toFixed(1)}  goldLeft ${avg('goldFound').toFixed(0)}  stuck ${stuck}  abilities ${avg('abilities').toFixed(1)}  dual ${(rows.filter(r => r.dual).length / rows.length * 100).toFixed(0)}%  heals ${avg('healsCast').toFixed(1)}  buffs ${avg('buffsCast').toFixed(1)}  shapes ${avg('shapes').toFixed(1)}  roots ${avg('roots').toFixed(1)}  cursed ${(avg('cursedTicks') / 1000).toFixed(1)}k ticks, freed ${avg('uncursed').toFixed(2)}, stuck at end ${(avg('cursedAtEnd') * 100).toFixed(0)}%  forged ${avg('forged').toFixed(1)}  runes ${avg('runes').toFixed(1)}  made ${avg('made').toFixed(1)}  tonics ${avg('tonics').toFixed(1)}  oils ${avg('oils').toFixed(1)} (bought ${avg('oilsBought').toFixed(1)})  charms ${avg('charms').toFixed(2)}  jobs ${avg('jobs').toFixed(2)} (paid ${avg('jobsPaid').toFixed(2)}, lost ${avg('jobsLost').toFixed(2)}, done unpaid ${avg('jobDoneUnpaid').toFixed(2)}, open at the end ${avg('jobOpen').toFixed(2)})  draughts bought ${avg('draughtsBought').toFixed(2)}  scrolls read ${avg('scrollsRead').toFixed(2)}  lodged ${avg('lodged').toFixed(1)}  answers struck ${avg('struckAside').toFixed(2)} burned ${avg('burned').toFixed(2)} shut ${avg('shut').toFixed(2)}  puff ${avg('puffAnswers').toFixed(2)}  rock ${avg('rockSteps').toFixed(2)}  fire ${avg('fireSteps').toFixed(2)} (fields ${avg('fieldsSeen').toFixed(2)})  flasks ${avg('flasksThrown').toFixed(2)} (lit ${avg('flasksLit').toFixed(2)}, bought ${avg('flasksBought').toFixed(2)})  relics ${avg('relics').toFixed(1)} (worn ${avg('relicsWorn').toFixed(1)}, bought ${avg('relicsBought').toFixed(2)})  legend ${(avg('legend') * 100).toFixed(0)}% (worn ${(avg('legendWorn') * 100).toFixed(0)}%)  combos ${avg('combos').toFixed(1)} (wins with one ${(rows.filter(r => !r.died && r.combos).length / Math.max(1, rows.filter(r => !r.died).length) * 100).toFixed(0)}%)  jewels ${avg("jewels").toFixed(2)} (bought ${avg("jewelsBought").toFixed(2)})  enc ${avg('encounters').toFixed(1)} (${(rows.reduce((a, r) => a + (r.encPass || 0), 0) / Math.max(1, rows.reduce((a, r) => a + (r.encPass || 0) + (r.encFail || 0), 0)) * 100).toFixed(0)}% pass)  diedOnFloor1 ${(rows.filter(r => r.died && r.deepest === 1).length / rows.length * 100).toFixed(0)}%  hound ${(rows.filter(r => r.hound).length / rows.length * 100).toFixed(0)}% (fell ${(rows.filter(r => r.houndFell).length / Math.max(1, rows.filter(r => r.hound).length) * 100).toFixed(0)}%, kills ${(rows.reduce((a, r) => a + (r.houndKills || 0), 0) / Math.max(1, rows.filter(r => r.hound).length)).toFixed(1)})`);
  if (process.env.COMBOS) console.log('   combos ' + Object.entries(comboSeen).sort((a, b) => b[1] - a[1]).map(([id, n]) => `${id} ${n}`).join(' | '));
  if (errs.length) console.log('   errors:', errs.slice(0, 2).map(e => e.cause).join(' | '));
  // Which path each run took, and how each did; runs that never chose one take none.
  const byPath = {};
  for (const r of rows) (byPath[r.path || 'none'] = byPath[r.path || 'none'] || []).push(r);
  console.log(`   paths ${Object.entries(byPath).map(([k, a]) => `${k} ${a.length} runs, win ${(a.filter(r => r.won).length / a.length * 100).toFixed(0)}%`).join(' | ')}`);
  // the build by floor: which floor the path, the capstone and the legend came on (ROADMAP Phase 8)
  const floors = k => { const by = {}; for (const r of rows) if (r[k]) by[r[k]] = (by[r[k]] || 0) + 1; return Object.entries(by).sort((a, b) => a[0] - b[0]).map(([f, n]) => `floor ${f} ${(n / rows.length * 100).toFixed(0)}%`).join(', ') || 'never'; };
  const wins = rows.filter(r => r.won);
  console.log(`   path on ${floors('pathAt')}; capstone on ${floors('capAt')} (${wins.length ? (wins.filter(r => r.capstone).length / wins.length * 100).toFixed(0) : 0}% of wins); legend on ${floors('legendAt')}, worn at the end ${(avg('legendWorn') * 100).toFixed(0)}%; winners end with ${wins.length ? (wins.reduce((a, r) => a + (r.potsAtEnd || 0), 0) / wins.length).toFixed(1) : '-'} draughts`);
  const byCap = {};
  for (const r of rows) if (r.capstone) (byCap[r.capstone] = byCap[r.capstone] || []).push(r);
  if (Object.keys(byCap).length) console.log(`   capstones ${Object.entries(byCap).map(([k, a]) => `${k} ${a.length}, win ${(a.filter(r => r.won).length / a.length * 100).toFixed(0)}%`).join(' | ')}`);
}
// GEAR=1 shows what each class ended its runs holding
if (process.env.GEAR) {
  for (const cls in results) {
    const t = {};
    for (const r of results[cls]) t[r.gear] = (t[r.gear] || 0) + 1;
    console.log(`   ${cls.padEnd(8)} ${Object.entries(t).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, n]) => `${k} ×${n}`).join(' | ')}`);
  }
}
// CASTS=1 shows how often each class cast each spell, per run
if (process.env.CASTS) {
  for (const cls in results) {
    const t = {};
    for (const r of results[cls]) for (const k in (r.casts || {})) t[k] = (t[k] || 0) + r.casts[k];
    console.log(`   ${cls.padEnd(8)} casts per run: ${Object.entries(t).map(([k, n]) => `${k} ${(n / results[cls].length).toFixed(1)}`).join(' | ')}`);
  }
}
// DEATHS=1 shows, per class, which floor runs died on and what killed them
if (process.env.DEATHS) {
  for (const cls in results) {
    const dead = results[cls].filter(r => r.died);
    const byFloor = {};
    for (const r of dead) byFloor[r.deepest] = (byFloor[r.deepest] || 0) + 1;
    const killers = {};
    for (const r of dead) killers[r.cause] = (killers[r.cause] || 0) + 1;
    const top = Object.entries(killers).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([k, n]) => `${k} ${n}`).join(', ');
    console.log(`   ${cls.padEnd(8)} died on floor: ${Object.entries(byFloor).map(([f, n]) => `${f}:${n}`).join(' ')}  | killers: ${top}`);
  }
}
// DETAIL=1: killers per floor, level at death, and the hero's state arriving on each floor
if (process.env.DETAIL) {
  for (const cls in results) {
    const rows = results[cls], dead = rows.filter(r => r.died);
    const byF = {};
    for (const r of dead) { const f = r.deepest; (byF[f] = byF[f] || {}); byF[f][r.cause] = (byF[f][r.cause] || 0) + 1; }
    for (const f of Object.keys(byF).sort((a, b) => a - b)) console.log(`   ${cls} F${f}: ${Object.entries(byF[f]).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${k} ${n}`).join(', ')}`);
    const lv = {}; for (const r of dead) { const k = `F${r.deepest}`; (lv[k] = lv[k] || []).push(r.level); }
    console.log(`   ${cls} heal potions carried at death: ${dead.map(r => `F${r.deepest}:${r.potsAtEnd}`).join(' ')}`);
    console.log(`   ${cls} level at death: ${Object.entries(lv).map(([k, a]) => `${k}:[${a.sort((x, y) => x - y).join(',')}]`).join(' ')}`);
    const line = [];
    for (let f = 1; f <= 8; f++) {
      const a = rows.filter(r => r.arrive && r.arrive[f]).map(r => r.arrive[f]);
      if (!a.length) continue;
      const av = k => (a.reduce((s, x) => s + x[k], 0) / a.length);
      line.push(`F${f} n${a.length} L${av('lvl').toFixed(1)} hp${av('hp').toFixed(0)}/${av('maxHp').toFixed(0)} pot${av('pots').toFixed(1)} g${av('gold').toFixed(0)} t${(av('t') / 60000).toFixed(1)}m`);
    }
    console.log(`   ${cls} arrive: ${line.join(' | ')}`);
    const wins = rows.filter(r => r.won);
    // past the top level: the floor it was reached on, how much experience was left over, and the renown it bought
    { const top = rows.filter(r => r.capped); if (top.length) console.log(`   ${cls} at the top level: ${top.length}/${rows.length} runs, reached on floor ${(top.reduce((a, r) => a + (r.topAt || 0), 0) / top.length).toFixed(1)}, xp past it ${(top.reduce((a, r) => a + r.pastTop, 0) / top.length).toFixed(0)} (most ${Math.max(...top.map(r => r.pastTop))}), renown ${(top.reduce((a, r) => a + r.renown, 0) / top.length).toFixed(2)}`); }
    if (wins.length) console.log(`   ${cls} winners end: level ${(wins.reduce((s, r) => s + r.level, 0) / wins.length).toFixed(1)}, gold ${(wins.reduce((s, r) => s + r.goldFound, 0) / wins.length).toFixed(0)}, potions drunk ${(wins.reduce((s, r) => s + r.potionsDrunk, 0) / wins.length).toFixed(1)}, hpLow ticks ${(wins.reduce((s, r) => s + r.hpLow, 0) / wins.length).toFixed(0)}, runs that dipped <30% hp ${wins.filter(r => r.hpLow > 0).length}/${wins.length}`);
  }
}
// DUMP=n (with DUMPF=floor): the last n log lines of each death on that floor
if (process.env.DUMP) {
  for (const cls in results) for (const r of results[cls]) {
    if (!r.died || (process.env.DUMPF && String(r.deepest) !== process.env.DUMPF)) continue;
    console.log(`--- ${cls} ${r.seed} ${r.bg} F${r.deepest} L${r.level} killed by ${r.cause}`);
    for (const m of r.tail || []) console.log('    ' + m);
  }
}
// ENCLOG=1: what encounters handed each class per run, and its commonest choices
if (process.env.ENCLOG) {
  for (const cls in results) {
    const rows = results[cls], tot = {}, chose = {};
    for (const r of rows) {
      for (const k in (r.encGot || {})) tot[k] = (tot[k] || 0) + r.encGot[k];
      for (const k in (r.encChose || {})) chose[k] = (chose[k] || 0) + r.encChose[k];
    }
    console.log(`   ${cls.padEnd(8)} per run: ${Object.entries(tot).map(([k, v]) => `${k} ${(v / rows.length).toFixed(1)}`).join('  ')}`);
    console.log(`            choices: ${Object.entries(chose).sort((a, b) => b[1] - a[1]).slice(0, 6).map(([k, v]) => `${k} ${(v / rows.length).toFixed(2)}`).join(' | ')}`);
  }
}
// RELICLOG=1: relics left lying, and whether they were reachable without a key
if (process.env.RELICLOG) {
  for (const cls in results) {
    const t = { reach: 0, locked: 0, full: 0 };
    for (const r of results[cls]) for (const k in (r.relicLeft || {})) t[k] += r.relicLeft[k];
    console.log(`   ${cls.padEnd(8)} relics left per run: reachable ${(t.reach / results[cls].length).toFixed(2)}, behind locks ${(t.locked / results[cls].length).toFixed(2)}; runs ending with a full pack ${t.full}`);
  }
}
// SHADE=n: how each class fared against the shade waiting on floor n
if (process.env.SHADE) {
  for (const cls in results) {
    const rows = results[cls], met = rows.filter(r => r.shadeMet);
    console.log(`   ${cls.padEnd(8)} met the shade in ${met.length} runs, laid it to rest in ${rows.filter(r => r.shadeRested).length}, killed by it in ${rows.filter(r => r.shadeKilled).length}`);
  }
}
// NAMED=1: for each named champion, how many runs reached its floor, how many
// slew it, and how many it killed
if (process.env.NAMED) {
  const t = {};
  for (const cls in results) for (const r of results[cls]) {
    const plan = r.namedHeld || [];
    for (const id of plan) (t[id] = t[id] || { held: 0, slain: 0, killed: 0 }).held++;
    // (one slain or a killer not in the plan, a renegade's quarry or a people's own, is counted all the same)
    const at = id => (t[id] = t[id] || { held: 0, slain: 0, killed: 0 });
    for (const id of r.namedSlain || []) at(id).slain++;
    if (r.namedKiller) at(r.namedKiller).killed++;
  }
  for (const id in t) console.log(`   ${id.padEnd(8)} held in ${t[id].held} runs, slain in ${t[id].slain}, killed the hero in ${t[id].killed}`);
}
// LICH=1: of the heroes who reached the last floor, how many died there and
// how many the lich itself killed, and what they bought at the vigil lamp
if (process.env.LICH) {
  for (const cls in results) {
    const last = results[cls].filter(r => r.deepest >= opts.levels);
    const died = last.filter(r => r.died), byLich = died.filter(r => /Lich|Warlord/.test(r.cause || ''));
    const lamp = {};
    for (const r of last) lamp[r.lamp || 'never reached'] = (lamp[r.lamp || 'never reached'] || 0) + 1;
    console.log(`   ${cls}: ${last.length} reached the last floor; ${died.length} died there (${(died.length / Math.max(1, last.length) * 100).toFixed(1)}%), ${byLich.length} to the lich (${(byLich.length / Math.max(1, last.length) * 100).toFixed(1)}%)`);
    const what = {};
    for (const r of died) { const k = `${r.cause || '?'} (level ${r.level || '?'})`; what[k] = (what[k] || 0) + 1; }
    console.log(`     killed by: ${Object.entries(what).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, n]) => `${k} ${n}`).join(' | ')}`);
    console.log(`     lamp: ${Object.entries(lamp).sort((a, b) => b[1] - a[1]).map(([k, n]) => `${k} ${n}`).join(' | ')}`);
  }
}
// CAUSES=1 lists what ended the runs that never left the first floor
if (process.env.CAUSES) {
  const tally = {};
  for (const cls in results) for (const r of results[cls]) {
    if (!(r.died && r.deepest === 1)) continue;
    const k = `${cls.padEnd(7)} ${r.cause || '?'} (level ${r.level || '?'})`;
    tally[k] = (tally[k] || 0) + 1;
  }
  Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 14).forEach(([k, n]) => console.log(`   ${String(n).padStart(3)}  ${k}`));
}
// EARLY=1 lists deaths below level 5 by cause and floor. Paths are now offered
// at level 3 or the divided stair; JSON records without a path measure pre-path deaths.
if (process.env.EARLY) {
  for (const cls in results) {
    const tally = {}, early = results[cls].filter(r => r.died && (r.level || 0) < 5);
    for (const r of early) { const k = `${r.cause || '?'} (floor ${r.deepest})`; tally[k] = (tally[k] || 0) + 1; }
    console.log(`   ${cls}: ${early.length} of ${results[cls].length} died before level 5`);
    Object.entries(tally).sort((a, b) => b[1] - a[1]).slice(0, 12).forEach(([k, n]) => console.log(`     ${String(n).padStart(3)}  ${k}`));
  }
}
console.log(`OVERALL win ${(totalWin / totalRuns * 100).toFixed(1)}%  avgDeepest ${(totalDeep / totalRuns).toFixed(2)}  (${totalRuns} runs)`);
// Keep exact counts and individual outcomes for an audit; the human-readable
// summary rounds percentages and cannot be used to reconstruct those counts.
if (process.env.JSON_OUT) require('fs').writeFileSync(process.env.JSON_OUT, JSON.stringify({
  format: 1, options: opts, seeds: SEEDS, trialsPerSeed: TRIALS, fit: !!process.env.FIT, results,
}) + '\n');
}

main().catch(e => { console.error(e); process.exit(1); });
